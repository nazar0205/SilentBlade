extends CharacterBody2D
class_name SilentBladePlayer

signal health_changed(value: float)
signal died
signal guard_changed(value: float, maximum: float)
signal guard_broken
signal parry_succeeded
signal noise_emitted(world_position: Vector2, radius: float, intensity: float, event_type: String, source_id: int)
signal distraction_requested(origin: Vector2, direction: int)
signal attack_started(attack_index: int)
signal attack_hit(target_instance_id: int, damage: float)
signal damage_received(amount: float)
signal grapple_used
signal distraction_used

const SPEED := 300.0
const ACCEL := 1800.0
const JUMP_VELOCITY := -520.0
const GRAVITY := 1350.0
const DASH_SPEED := 760.0
const DASH_TIME := 0.20
const DASH_COOLDOWN := 0.82
const DASH_ACCEL_TIME := 0.065
const DASH_EXIT_SPEED := 420.0
const DASH_EXIT_DURATION := 0.22
const DASH_EXIT_DRAG := 520.0
const MAX_JUMPS := 2
const COYOTE_TIME := 0.12
const JUMP_BUFFER_TIME := 0.15
const JUMP_CUT_MULTIPLIER := 0.48
const JUMP_HOLD_GRAVITY_SCALE := 0.62
const JUMP_HOLD_DURATION := 0.22
const SECOND_JUMP_FLASH_TIME := 0.24
const GRAPPLE_RANGE := 430.0
const GRAPPLE_MIN_ROPE_LENGTH := 90.0
const GRAPPLE_PUMP_ACCEL := 560.0
const GRAPPLE_REEL_SPEED := 85.0
const GRAPPLE_TARGET_REFRESH := 0.12
const GRAPPLE_COLLISION_MASK := 1
const PARRY_WINDOW := 0.18
const COMBO_LINK_WINDOW := 0.85
const ATTACK_BUFFER_TIME := 0.24
const MOVEMENT_FRAMES: SpriteFrames = preload("res://assets/characters/player/player_movement_frames.tres")
const MOBILITY_FRAMES: SpriteFrames = preload("res://assets/characters/player/player_mobility_frames.tres")
const PLAYER_ANIMATION_STATES := ["IDLE", "WALK", "RUN", "CROUCH", "JUMP", "FALL", "LAND", "DASH", "GRAPPLE_SHOOT", "GRAPPLE_SWING", "ATTACK_1", "ATTACK_2", "ATTACK_3", "BLOCK", "PARRY", "HIT", "DEATH"]
const SPRITE_MOVEMENT_SCALE := 0.42
const SPRITE_MOBILITY_SCALE := 0.32
const GRAPPLE_SHOOT_VISUAL_TIME := 0.50
const LAND_VISUAL_TIME := 0.40
const COMBO_ATTACKS := [
	{
		"name": "QUICK SLASH",
		"damage": 22.0,
		"windup_time": 0.055,
		"active_time": 0.12,
		"recovery_time": 0.16,
		"cooldown": 0.27,
		"hitbox_size": Vector2(74.0, 34.0),
		"hitbox_offset": Vector2(48.0, -35.0),
		"knockback": 155.0,
		"visual_style": "QUICK"
	},
	{
		"name": "CROSS CUT",
		"damage": 31.0,
		"windup_time": 0.085,
		"active_time": 0.16,
		"recovery_time": 0.18,
		"cooldown": 0.32,
		"hitbox_size": Vector2(88.0, 44.0),
		"hitbox_offset": Vector2(54.0, -41.0),
		"knockback": 245.0,
		"visual_style": "CROSS"
	},
	{
		"name": "HEAVY FINISHER",
		"damage": 48.0,
		"windup_time": 0.14,
		"active_time": 0.23,
		"recovery_time": 0.28,
		"cooldown": 0.50,
		"hitbox_size": Vector2(112.0, 56.0),
		"hitbox_offset": Vector2(65.0, -40.0),
		"knockback": 430.0,
		"visual_style": "FINISHER"
	}
]
const GUARD_MAX := 100.0
const GUARD_REGEN_PER_SECOND := 24.0
const GUARD_DAMAGE_PER_HIT := 34.0
const GUARD_BREAK_DAMAGE_RATIO := 0.67
const BLOCK_DAMAGE_RATIO := 0.22
const GUARD_BREAK_TIME := 1.35
const COUNTER_WINDOW := 1.1
const DISTRACTION_COOLDOWN := 3.2

var health := 100.0
var facing := 1
var crouching := false
var attacking := false
var attack_timer := 0.0
var attack_cooldown := 0.0
var attack_active := false
var attack_phase := "IDLE"
var attack_phase_timer := 0.0
var attack_buffer_timer := 0.0
var current_attack_windup := 0.0
var current_attack_recovery := 0.0
var animation_state := "IDLE"
var animation_elapsed := 0.0
var animation_sprite: AnimatedSprite2D
var grapple_shoot_visual_timer := 0.0
var _last_sprite_animation := ""
var land_animation_timer := 0.0
var hit_flash_timer := 0.0
var death_animation_timer := 0.0
var current_attack_damage := 22.0
var current_attack_knockback := 155.0
var current_attack_index := -1
var current_attack_name := ""
var current_attack_visual_style := "QUICK"
var current_attack_hitbox_size := Vector2(74.0, 34.0)
var current_attack_hitbox_offset := Vector2(48.0, -35.0)
var combo_step := 0
var combo_timer := 0.0
var attack_hitbox: Area2D
var attack_shape: CollisionShape2D
var attack_rect: RectangleShape2D
var hit_ids_this_swing: Dictionary = {}
var dash_timer := 0.0
var dash_cooldown := 0.0
var dash_elapsed := 0.0
var dash_direction := 1
var dash_start_velocity := 0.0
var dash_exit_timer := 0.0
var jump_count := 0
var coyote_timer := 0.0
var jump_buffer_timer := 0.0
var jump_hold_timer := 0.0
var second_jump_flash_timer := 0.0
var grapple_point: Vector2 = Vector2.ZERO
var grapple_target: Vector2 = Vector2.ZERO
var grapple_scan_timer := 0.0
var grappling := false
var rope_length := 0.0
var anchors: Array[Vector2] = []
var invuln := 0.0

var block_held := false
var parry_timer := 0.0
var guard_stamina := GUARD_MAX
var guard_break_timer := 0.0
var counter_window_timer := 0.0
var parry_flash_timer := 0.0
var block_flash_timer := 0.0
var guard_is_broken := false
var footstep_noise_timer := 0.0
var distraction_cooldown := 0.0

func _ready() -> void:
	collision_layer = 1
	collision_mask = 3
	var shape := CollisionShape2D.new()
	var capsule := CapsuleShape2D.new()
	capsule.radius = 17.0
	capsule.height = 58.0
	shape.shape = capsule
	shape.position = Vector2(0, -30)
	add_child(shape)
	_create_attack_hitbox()
	_create_animation_sprite()
	floor_snap_length = 8.0
	floor_max_angle = deg_to_rad(48.0)
	guard_changed.emit(guard_stamina, GUARD_MAX)

func _process(delta: float) -> void:
	if death_animation_timer > 0.0:
		death_animation_timer = maxf(0.0, death_animation_timer - delta)
		animation_elapsed += delta
		queue_redraw()

func _create_attack_hitbox() -> void:
	attack_hitbox = Area2D.new()
	attack_hitbox.name = "AttackHitbox"
	attack_hitbox.collision_layer = 0
	attack_hitbox.collision_mask = 2
	attack_hitbox.monitoring = false
	attack_hitbox.monitorable = false
	attack_hitbox.position = Vector2(48, -36)
	attack_shape = CollisionShape2D.new()
	attack_shape.name = "AttackShape"
	attack_rect = RectangleShape2D.new()
	attack_rect.size = current_attack_hitbox_size
	attack_shape.shape = attack_rect
	attack_hitbox.add_child(attack_shape)
	attack_hitbox.body_entered.connect(_on_attack_body_entered)
	add_child(attack_hitbox)

func _physics_process(delta: float) -> void:
	var was_on_floor := is_on_floor()
	invuln = maxf(0.0, invuln - delta)
	attack_cooldown = maxf(0.0, attack_cooldown - delta)
	combo_timer = maxf(0.0, combo_timer - delta)
	attack_buffer_timer = maxf(0.0, attack_buffer_timer - delta)
	second_jump_flash_timer = maxf(0.0, second_jump_flash_timer - delta)
	hit_flash_timer = maxf(0.0, hit_flash_timer - delta)
	land_animation_timer = maxf(0.0, land_animation_timer - delta)
	grapple_shoot_visual_timer = maxf(0.0, grapple_shoot_visual_timer - delta)
	if combo_timer <= 0.0 and not attack_active:
		combo_step = 0
	if dash_cooldown > 0.0:
		dash_cooldown = maxf(0.0, dash_cooldown - delta)
	if dash_exit_timer > 0.0:
		dash_exit_timer = maxf(0.0, dash_exit_timer - delta)
	_update_defense(delta)
	_update_jump_timers(delta)
	distraction_cooldown = maxf(0.0, distraction_cooldown - delta)
	_update_attack_sequence(delta)
	_try_start_buffered_combo()

	if Input.is_action_just_pressed("block"):
		begin_block()
	if Input.is_action_just_released("block"):
		end_block()
	if Input.is_action_just_pressed("attack"):
		if attacking or (attack_cooldown > 0.0 and combo_timer > 0.0):
			_buffer_attack_input()
		else:
			start_attack()
	if Input.is_action_just_pressed("distract") and distraction_cooldown <= 0.0 and health > 0.0:
		distraction_cooldown = DISTRACTION_COOLDOWN
		distraction_used.emit()
		distraction_requested.emit(global_position + Vector2(24.0 * facing, -42.0), facing)
	if Input.is_action_just_pressed("crouch"):
		crouching = true
	if Input.is_action_just_released("crouch"):
		crouching = false
	if Input.is_action_just_released("jump") and velocity.y < 0.0:
		velocity.y *= JUMP_CUT_MULTIPLIER
		jump_hold_timer = 0.0

	var axis := Input.get_axis("move_left", "move_right")
	if absf(axis) > 0.1:
		facing = 1 if axis > 0.0 else -1
		_update_attack_facing()

	if Input.is_action_just_pressed("dash") and dash_cooldown <= 0.0 and not block_held and not guard_is_broken and health > 0.0:
		_start_dash(axis)
	grapple_scan_timer = maxf(0.0, grapple_scan_timer - delta)
	if not grappling and grapple_scan_timer <= 0.0:
		grapple_target = _find_grapple_anchor()
		grapple_scan_timer = GRAPPLE_TARGET_REFRESH
	if Input.is_action_just_pressed("grapple") and not grappling:
		_attach_grapple()
	if Input.is_action_just_released("grapple") and grappling:
		_detach_grapple()

	_try_consume_jump_buffer()
	_update_footstep_noise(delta, axis)
	if dash_timer > 0.0:
		_update_dash(delta)
	else:
		if grappling:
			_apply_grapple_control(delta, axis, Input.is_action_pressed("grapple"))
		else:
			var target_speed := axis * (SPEED * (0.48 if crouching else 1.0))
			var horizontal_accel := ACCEL
			if dash_exit_timer > 0.0:
				horizontal_accel = DASH_EXIT_DRAG
			velocity.x = move_toward(velocity.x, target_speed, horizontal_accel * delta)
		if not is_on_floor() or velocity.y < 0.0:
			var gravity_scale := 1.0
			if velocity.y < 0.0 and jump_hold_timer > 0.0 and Input.is_action_pressed("jump"):
				gravity_scale = JUMP_HOLD_GRAVITY_SCALE
			velocity.y += GRAVITY * gravity_scale * delta
		else:
			jump_hold_timer = 0.0
		jump_hold_timer = maxf(0.0, jump_hold_timer - delta)

	var impact_speed := velocity.y
	move_and_slide()
	if not was_on_floor and is_on_floor():
		land_animation_timer = LAND_VISUAL_TIME
	if not was_on_floor and is_on_floor() and impact_speed > 180.0:
		var landing_event := "FALL" if impact_speed >= 450.0 else "LAND"
		var landing_radius := clampf(100.0 + impact_speed * 0.34, 150.0, 390.0)
		var landing_intensity := clampf(impact_speed / 920.0, 0.25, 1.0)
		noise_emitted.emit(global_position, landing_radius, landing_intensity, landing_event, get_instance_id())
	if grappling:
		_constrain_rope_after_motion()
		if grappling and not _has_clear_grapple_line(grapple_point):
			_detach_grapple()
	if is_on_floor() and velocity.y >= 0.0:
		jump_count = 0
		coyote_timer = COYOTE_TIME
		if jump_buffer_timer > 0.0:
			_try_consume_jump_buffer()
	_update_animation_state(delta)
	queue_redraw()

func _update_jump_timers(delta: float) -> void:
	if Input.is_action_just_pressed("jump"):
		jump_buffer_timer = JUMP_BUFFER_TIME
	else:
		jump_buffer_timer = maxf(0.0, jump_buffer_timer - delta)
	if is_on_floor() and velocity.y >= 0.0:
		jump_count = 0
		coyote_timer = COYOTE_TIME
	else:
		coyote_timer = maxf(0.0, coyote_timer - delta)
		if coyote_timer <= 0.0 and jump_count == 0:
			# Walked off a ledge and the coyote window is gone: the ground jump is spent,
			# the air jump stays available (otherwise the player could not jump at all).
			jump_count = 1

func _try_consume_jump_buffer() -> bool:
	if jump_buffer_timer <= 0.0 or block_held or dash_timer > 0.0 or guard_is_broken:
		return false
	# A deliberate jump always releases the line, even if both jump charges are spent.
	if grappling:
		_detach_grapple()
	if (is_on_floor() and velocity.y >= 0.0) or (jump_count == 0 and coyote_timer > 0.0):
		jump_count = 1
		velocity.y = JUMP_VELOCITY
		coyote_timer = 0.0
		jump_buffer_timer = 0.0
		jump_hold_timer = JUMP_HOLD_DURATION
		_last_sprite_animation = ""
		noise_emitted.emit(global_position, 205.0, 0.48, "JUMP", get_instance_id())
		return true
	if jump_count < MAX_JUMPS and jump_count == 1:
		jump_count += 1
		velocity.y = JUMP_VELOCITY * 0.94
		jump_buffer_timer = 0.0
		jump_hold_timer = JUMP_HOLD_DURATION
		_last_sprite_animation = ""
		noise_emitted.emit(global_position, 230.0, 0.58, "JUMP", get_instance_id())
		_play_second_jump_effect()
		return true
	return false

func notify_interaction_noise(event_type: String = "INTERACTION", radius: float = 190.0, intensity: float = 0.55) -> void:
	# Interactable world objects can call this on the player without owning noise propagation.
	noise_emitted.emit(global_position, maxf(0.0, radius), clampf(intensity, 0.0, 1.0), event_type, get_instance_id())

func _update_footstep_noise(delta: float, axis: float) -> void:
	if absf(axis) <= 0.25 or dash_timer > 0.0 or not is_on_floor():
		footstep_noise_timer = minf(footstep_noise_timer, 0.12)
		return
	footstep_noise_timer -= delta
	if footstep_noise_timer > 0.0:
		return
	if crouching:
		noise_emitted.emit(global_position, 92.0, 0.16, "SNEAK_STEP", get_instance_id())
		footstep_noise_timer = 0.72
	else:
		var run_factor := clampf(absf(velocity.x) / SPEED, 0.25, 1.0)
		noise_emitted.emit(global_position, 170.0 + run_factor * 70.0, 0.32 + run_factor * 0.16, "FOOTSTEP", get_instance_id())
		footstep_noise_timer = 0.42

func _play_second_jump_effect() -> void:
	second_jump_flash_timer = SECOND_JUMP_FLASH_TIME

func _start_dash(axis: float) -> void:
	dash_direction = (1 if axis > 0.1 else (-1 if axis < -0.1 else facing))
	if grappling:
		_detach_grapple()
	dash_start_velocity = velocity.x
	dash_elapsed = 0.0
	dash_timer = DASH_TIME
	dash_cooldown = DASH_COOLDOWN
	dash_exit_timer = 0.0
	noise_emitted.emit(global_position, 340.0, 0.90, "DASH", get_instance_id())

func _update_dash(delta: float) -> void:
	dash_elapsed += delta
	dash_timer = maxf(0.0, dash_timer - delta)
	var ramp := clampf(dash_elapsed / DASH_ACCEL_TIME, 0.0, 1.0)
	var eased_ramp := ramp * ramp * (3.0 - 2.0 * ramp)
	velocity.x = lerpf(dash_start_velocity, float(dash_direction) * DASH_SPEED, eased_ramp)
	velocity.y = move_toward(velocity.y, 0.0, GRAVITY * 1.8 * delta)
	if dash_timer <= 0.0:
		velocity.x = float(dash_direction) * DASH_EXIT_SPEED
		dash_exit_timer = DASH_EXIT_DURATION

func _update_attack_facing() -> void:
	if attack_hitbox:
		attack_hitbox.position.x = absf(current_attack_hitbox_offset.x) * facing

func _buffer_attack_input() -> void:
	if block_held or guard_is_broken or health <= 0.0 or dash_timer > 0.0:
		return
	if combo_timer > 0.0 and combo_step > 0:
		attack_buffer_timer = ATTACK_BUFFER_TIME

func _consume_attack_buffer() -> void:
	if attack_buffer_timer <= 0.0 or combo_timer <= 0.0 or combo_step <= 0:
		return
	attack_buffer_timer = 0.0
	start_attack()

func _try_start_buffered_combo() -> void:
	if attack_buffer_timer <= 0.0:
		return
	if combo_timer <= 0.0 or combo_step <= 0:
		attack_buffer_timer = 0.0
		return
	if not attacking and not block_held and not guard_is_broken and health > 0.0 and dash_timer <= 0.0:
		# Follow-up strikes are allowed during their authored combo link window;
		# the base attack cooldown only gates starting a fresh combo.
		_consume_attack_buffer()

func start_attack() -> void:
	if attack_cooldown > 0.0 and combo_step == 0:
		return
	if attacking or block_held or guard_is_broken or dash_timer > 0.0 or health <= 0.0:
		return
	current_attack_index = combo_step
	var profile: Dictionary = COMBO_ATTACKS[current_attack_index]
	current_attack_name = String(profile["name"])
	current_attack_damage = float(profile["damage"])
	current_attack_knockback = float(profile["knockback"])
	current_attack_visual_style = String(profile["visual_style"])
	current_attack_hitbox_size = profile["hitbox_size"]
	current_attack_hitbox_offset = profile["hitbox_offset"]
	current_attack_windup = float(profile["windup_time"])
	current_attack_recovery = float(profile["recovery_time"])
	attack_phase = "WINDUP"
	attack_phase_timer = current_attack_windup
	attack_timer = current_attack_windup + float(profile["active_time"]) + current_attack_recovery
	attack_active = false
	attacking = true
	attack_cooldown = float(profile["cooldown"])
	combo_step = (current_attack_index + 1) % COMBO_ATTACKS.size()
	combo_timer = COMBO_LINK_WINDOW
	if counter_window_timer > 0.0:
		current_attack_damage *= 1.5
		counter_window_timer = 0.0
	hit_ids_this_swing.clear()
	attack_rect.size = current_attack_hitbox_size
	attack_hitbox.position = Vector2(absf(current_attack_hitbox_offset.x) * facing, current_attack_hitbox_offset.y)
	attack_hitbox.set_deferred("monitoring", false)
	noise_emitted.emit(global_position, 220.0 if current_attack_index < 2 else 280.0, 0.66 if current_attack_index < 2 else 0.82, "ATTACK", get_instance_id())
	attack_started.emit(current_attack_index)

func _begin_attack_active_phase() -> void:
	attack_phase = "ACTIVE"
	attack_phase_timer = float(COMBO_ATTACKS[current_attack_index]["active_time"])
	attack_active = true
	attack_hitbox.set_deferred("monitoring", true)
	call_deferred("_scan_attack_overlaps")

func _end_attack_active_phase() -> void:
	attack_active = false
	attack_hitbox.set_deferred("monitoring", false)

func _finish_attack_sequence() -> void:
	_end_attack_active_phase()
	attack_phase = "IDLE"
	attack_phase_timer = 0.0
	attack_timer = 0.0
	attacking = false
	_consume_attack_buffer()

func _update_attack_sequence(delta: float) -> void:
	if not attacking:
		return
	var remaining := delta
	var transitions := 0
	while attacking and transitions < 4:
		if attack_phase_timer > 0.0 and remaining > 0.0:
			var consumed := minf(remaining, attack_phase_timer)
			attack_phase_timer -= consumed
			attack_timer = maxf(0.0, attack_timer - consumed)
			remaining -= consumed
		if attack_phase_timer > 0.00001:
			break
		transitions += 1
		match attack_phase:
			"WINDUP":
				_begin_attack_active_phase()
			"ACTIVE":
				_end_attack_active_phase()
				attack_phase = "RECOVERY"
				attack_phase_timer = current_attack_recovery
			"RECOVERY":
				_finish_attack_sequence()
			_:
				_finish_attack_sequence()
		if remaining <= 0.0 and attack_phase_timer > 0.0:
			break

func _update_animation_state(delta: float) -> void:
	var next_state := "IDLE"
	if health <= 0.0:
		next_state = "DEATH"
	elif hit_flash_timer > 0.0:
		next_state = "HIT"
	elif parry_flash_timer > 0.0:
		next_state = "PARRY"
	elif attacking:
		next_state = "ATTACK_%d" % (current_attack_index + 1)
	elif block_held and not guard_is_broken:
		next_state = "BLOCK"
	elif dash_timer > 0.0:
		next_state = "DASH"
	elif grappling and grapple_shoot_visual_timer > 0.0:
		next_state = "GRAPPLE_SHOOT"
	elif grappling:
		next_state = "GRAPPLE_SWING"
	elif crouching:
		next_state = "CROUCH"
	elif not is_on_floor():
		next_state = "JUMP" if velocity.y < -25.0 else "FALL"
	elif land_animation_timer > 0.0:
		next_state = "LAND"
	elif absf(velocity.x) > 24.0:
		next_state = "RUN" if absf(velocity.x) >= SPEED * 0.72 else "WALK"
	if next_state not in PLAYER_ANIMATION_STATES:
		next_state = "IDLE"
	if animation_state != next_state:
		animation_state = next_state
		animation_elapsed = 0.0
	else:
		animation_elapsed += delta
	_sync_animation_sprite()

func _create_animation_sprite() -> void:
	animation_sprite = AnimatedSprite2D.new()
	animation_sprite.name = "PlayerAnimatedSprite"
	animation_sprite.centered = true
	animation_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	animation_sprite.z_index = 1
	var merged_frames := SpriteFrames.new()
	if merged_frames.has_animation("default"):
		merged_frames.remove_animation("default")
	_copy_sprite_animations(MOVEMENT_FRAMES, ["idle", "walk", "run", "crouch", "jump", "fall", "land"], merged_frames)
	_copy_sprite_animations(MOBILITY_FRAMES, ["dash", "grapple_shoot", "grapple_swing"], merged_frames)
	animation_sprite.sprite_frames = merged_frames
	add_child(animation_sprite)
	_sync_animation_sprite(true)

func _copy_sprite_animations(source: SpriteFrames, animation_names: Array[String], destination: SpriteFrames) -> void:
	for animation_name in animation_names:
		if not source.has_animation(animation_name):
			push_warning("Player animation missing from SpriteFrames: %s" % animation_name)
			continue
		destination.add_animation(animation_name)
		destination.set_animation_speed(animation_name, source.get_animation_speed(animation_name))
		destination.set_animation_loop(animation_name, source.get_animation_loop(animation_name))
		for frame_index in range(source.get_frame_count(animation_name)):
			destination.add_frame(animation_name, source.get_frame_texture(animation_name, frame_index), source.get_frame_duration(animation_name, frame_index))

func _sync_animation_sprite(force: bool = false) -> void:
	if not is_instance_valid(animation_sprite):
		return
	var animation_name := ""
	match animation_state:
		"IDLE": animation_name = "idle"
		"WALK": animation_name = "walk"
		"RUN": animation_name = "run"
		"CROUCH": animation_name = "crouch"
		"JUMP": animation_name = "jump"
		"FALL": animation_name = "fall"
		"LAND": animation_name = "land"
		"DASH": animation_name = "dash"
		"GRAPPLE_SHOOT": animation_name = "grapple_shoot"
		"GRAPPLE_SWING": animation_name = "grapple_swing"
		_:
			animation_sprite.visible = false
			_last_sprite_animation = ""
			return
	animation_sprite.visible = true
	animation_sprite.flip_h = facing < 0
	animation_sprite.speed_scale = 2.5 if animation_name == "dash" else 1.0
	if animation_name in ["dash", "grapple_shoot", "grapple_swing"]:
		animation_sprite.scale = Vector2(SPRITE_MOBILITY_SCALE, SPRITE_MOBILITY_SCALE)
		animation_sprite.position = Vector2(0.0, -38.4)
	else:
		animation_sprite.scale = Vector2(SPRITE_MOVEMENT_SCALE, SPRITE_MOVEMENT_SCALE)
		animation_sprite.position = Vector2(0.0, -34.4)
	if force or animation_name != _last_sprite_animation:
		_last_sprite_animation = animation_name
		animation_sprite.play(animation_name)

func _scan_attack_overlaps() -> void:
	if not attack_active or not is_instance_valid(attack_hitbox):
		return
	for body in attack_hitbox.get_overlapping_bodies():
		_register_attack_target(body)

func _on_attack_body_entered(body: Node2D) -> void:
	_register_attack_target(body)

func _register_attack_target(body: Node) -> void:
	if not attack_active or not is_instance_valid(body) or not body.has_method("receive_damage"):
		return
	var target_id := body.get_instance_id()
	if hit_ids_this_swing.has(target_id):
		return
	var direction_to_target := signf(body.global_position.x - global_position.x)
	if direction_to_target == 0.0 or int(direction_to_target) != facing:
		return
	hit_ids_this_swing[target_id] = true
	body.call("receive_damage", current_attack_damage, global_position, current_attack_knockback)
	attack_hit.emit(target_id, current_attack_damage)

func _end_attack() -> void:
	_end_attack_active_phase()
	attack_phase = "IDLE"
	attack_phase_timer = 0.0
	attack_timer = 0.0
	attacking = false
	attack_buffer_timer = 0.0

func begin_block() -> void:
	if guard_is_broken or block_held:
		return
	block_held = true
	parry_timer = PARRY_WINDOW
	block_flash_timer = 0.0

func end_block() -> void:
	block_held = false
	parry_timer = 0.0

func _update_defense(delta: float) -> void:
	parry_timer = maxf(0.0, parry_timer - delta)
	counter_window_timer = maxf(0.0, counter_window_timer - delta)
	parry_flash_timer = maxf(0.0, parry_flash_timer - delta)
	block_flash_timer = maxf(0.0, block_flash_timer - delta)
	if guard_is_broken:
		guard_break_timer = maxf(0.0, guard_break_timer - delta)
		if guard_break_timer <= 0.0:
			guard_is_broken = false
			guard_stamina = GUARD_MAX * 0.35
			guard_changed.emit(guard_stamina, GUARD_MAX)
	elif not block_held and guard_stamina < GUARD_MAX:
		var previous := guard_stamina
		guard_stamina = minf(GUARD_MAX, guard_stamina + GUARD_REGEN_PER_SECOND * delta)
		if not is_equal_approx(previous, guard_stamina):
			guard_changed.emit(guard_stamina, GUARD_MAX)

func _faces_attacker(attacker: Node2D) -> bool:
	var side := signf(attacker.global_position.x - global_position.x)
	return side != 0.0 and int(side) == facing

func try_parry(attacker: Node2D) -> bool:
	if not block_held or parry_timer <= 0.0 or guard_is_broken or not _faces_attacker(attacker):
		return false
	if attacker.has_method("interrupt_attack"):
		attacker.interrupt_attack()
	counter_window_timer = COUNTER_WINDOW
	parry_flash_timer = 0.32
	parry_succeeded.emit()
	return true

func receive_enemy_attack(attacker: Node2D) -> String:
	var incoming_damage := 18.0
	if attacker.has_method("get_attack_damage"):
		incoming_damage = float(attacker.call("get_attack_damage"))
	if try_parry(attacker):
		return "PARRIED"
	if block_held and not guard_is_broken and _faces_attacker(attacker):
		guard_stamina = maxf(0.0, guard_stamina - GUARD_DAMAGE_PER_HIT)
		guard_changed.emit(guard_stamina, GUARD_MAX)
		block_flash_timer = 0.2
		if guard_stamina <= 0.0:
			_break_guard()
			take_damage(incoming_damage * GUARD_BREAK_DAMAGE_RATIO)
			return "GUARD_BROKEN"
		return "BLOCKED"
	take_damage(incoming_damage)
	return "HIT"

func receive_blocked_hit(_attacker: Node2D) -> void:
	# Public combat hook retained for future enemy attack types.
	pass

func _break_guard() -> void:
	guard_is_broken = true
	block_held = false
	parry_timer = 0.0
	guard_break_timer = GUARD_BREAK_TIME
	guard_broken.emit()

func release_controls() -> void:
	crouching = false
	_detach_grapple()
	dash_timer = 0.0
	dash_exit_timer = 0.0
	jump_buffer_timer = 0.0
	jump_hold_timer = 0.0
	attack_timer = 0.0
	attacking = false
	_end_attack()
	end_block()
	velocity.x = 0.0

func _find_grapple_anchor() -> Vector2:
	var best_point := Vector2.ZERO
	var best_distance := GRAPPLE_RANGE
	for point in anchors:
		var distance := global_position.distance_to(point)
		if distance >= best_distance or (point.x - global_position.x) * facing <= -80.0:
			continue
		if _has_clear_grapple_line(point):
			best_distance = distance
			best_point = point
	return best_point

func _attach_grapple() -> void:
	if grappling:
		return
	var chosen := _find_grapple_anchor()
	if chosen == Vector2.ZERO:
		return
	grapple_point = chosen
	# Attach at the measured distance: no snap, pull or position change on the attach frame.
	rope_length = maxf(GRAPPLE_MIN_ROPE_LENGTH, global_position.distance_to(chosen))
	grapple_target = chosen
	grappling = true
	grapple_shoot_visual_timer = GRAPPLE_SHOOT_VISUAL_TIME
	grapple_used.emit()
	noise_emitted.emit(global_position, 145.0, 0.30, "GRAPPLE", get_instance_id())

func _has_clear_grapple_line(point: Vector2) -> bool:
	var ray_origin := global_position + Vector2(0.0, -30.0)
	var query := PhysicsRayQueryParameters2D.create(ray_origin, point, GRAPPLE_COLLISION_MASK)
	query.exclude = [get_rid()]
	query.collide_with_areas = false
	var result := get_world_2d().direct_space_state.intersect_ray(query)
	return result.is_empty()

func _apply_grapple_control(delta: float, axis: float, reel: bool) -> void:
	var offset := global_position - grapple_point
	var distance := offset.length()
	if distance < 0.001:
		return
	var radial := offset / distance
	var tangent := Vector2(-radial.y, radial.x)
	if not is_zero_approx(axis):
		if tangent.dot(Vector2(axis, 0.0)) < 0.0:
			tangent = -tangent
		velocity += tangent * (absf(axis) * GRAPPLE_PUMP_ACCEL * delta)
	if reel:
		# Shorten the rope gradually; the post-motion collision solver performs the pull.
		rope_length = maxf(GRAPPLE_MIN_ROPE_LENGTH, rope_length - GRAPPLE_REEL_SPEED * delta)

func _constrain_rope_after_motion() -> void:
	var offset := global_position - grapple_point
	var distance := offset.length()
	if distance <= rope_length or distance < 0.001:
		return
	var radial := offset / distance
	var excess := distance - rope_length
	# Resolve only the small post-physics excess through the body's collision solver.
	# This preserves platform/wall collisions and avoids teleporting global_position.
	var rope_collision := move_and_collide(-radial * excess)
	if rope_collision != null:
		# If a solid body prevents the correction, relax the target length to the
		# physically reachable distance instead of storing impossible rope tension.
		var blocked_distance := global_position.distance_to(grapple_point)
		if blocked_distance > rope_length + 1.0:
			rope_length = blocked_distance
	var outward_speed := velocity.dot(radial)
	if outward_speed > 0.0:
		velocity -= radial * outward_speed

func _detach_grapple() -> void:
	# Intentionally leave velocity untouched so tangential momentum survives release.
	grappling = false
	grapple_shoot_visual_timer = 0.0
	grapple_point = Vector2.ZERO
	rope_length = 0.0
	grapple_scan_timer = 0.0

func kill() -> void:
	# Used for falling out of the world; ignores invulnerability frames.
	if health <= 0.0:
		return
	health = 0.0
	health_changed.emit(health)
	_begin_death_animation()
	died.emit()

func take_damage(amount: float) -> void:
	if invuln > 0.0:
		return
	var applied_damage := minf(health, maxf(0.0, amount))
	health = maxf(0.0, health - applied_damage)
	invuln = 0.7
	hit_flash_timer = 0.22
	damage_received.emit(applied_damage)
	health_changed.emit(health)
	if health <= 0.0:
		_begin_death_animation()
		died.emit()

func _begin_death_animation() -> void:
	animation_state = "DEATH"
	animation_elapsed = 0.0
	death_animation_timer = 0.5
	attack_buffer_timer = 0.0
	_end_attack()
	end_block()
	_detach_grapple()
	velocity = Vector2.ZERO
	queue_redraw()

func _draw_visual_overlays() -> void:
	if second_jump_flash_timer > 0.0:
		var effect_progress := second_jump_flash_timer / SECOND_JUMP_FLASH_TIME
		var effect_alpha := clampf(effect_progress, 0.0, 1.0)
		draw_arc(Vector2(0, -28), 31.0 + (1.0 - effect_progress) * 24.0, 0.0, TAU, 24, Color(0.48, 0.88, 1.0, effect_alpha), 3.0)
		draw_line(Vector2(-22, -10), Vector2(-38, 8), Color(0.66, 0.93, 1.0, effect_alpha), 3.0)
		draw_line(Vector2(22, -10), Vector2(38, 8), Color(0.66, 0.93, 1.0, effect_alpha), 3.0)
	if grappling:
		var anchor_local := to_local(grapple_point)
		draw_line(Vector2(0, -48), anchor_local, Color(0.08, 0.11, 0.18, 0.85), 5.0)
		draw_line(Vector2(0, -48), anchor_local, Color("d4d7e5"), 2.4)
		draw_circle(anchor_local, 5.0, Color("f1d39a"))
		draw_arc(anchor_local, 13.0, 0.0, TAU, 20, Color("f1d39a", 0.88), 2.0)
	elif grapple_target != Vector2.ZERO:
		var target_local := to_local(grapple_target)
		draw_circle(target_local, 5.0, Color(0.52, 0.84, 0.86, 0.88))
		draw_arc(target_local, 17.0, 0.0, TAU, 24, Color(0.52, 0.84, 0.86, 0.72), 2.2)

func _draw() -> void:
	if is_instance_valid(animation_sprite) and animation_sprite.visible:
		_draw_visual_overlays()
		return
	if animation_state == "DEATH":
		var progress := clampf(1.0 - death_animation_timer / 0.5, 0.0, 1.0)
		var alpha := 0.92 - progress * 0.42
		var body := Color(0.10, 0.12, 0.19, alpha)
		var cloth := Color(0.42, 0.08, 0.16, alpha)
		draw_line(Vector2(-30.0, -4.0 + progress * 4.0), Vector2(26.0, -4.0 + progress * 4.0), body, 13.0)
		draw_circle(Vector2(30.0, -13.0 + progress * 2.0), 10.0, body.lightened(0.15))
		draw_line(Vector2(-9.0, -2.0), Vector2(-28.0, 8.0 + progress * 4.0), body, 5.0)
		draw_line(Vector2(5.0, -2.0), Vector2(25.0, 8.0 + progress * 4.0), body, 5.0)
		draw_line(Vector2(-2.0, -7.0), Vector2(-19.0, -18.0), body, 5.0)
		draw_line(Vector2(10.0, -8.0), Vector2(27.0, -23.0), body, 5.0)
		draw_line(Vector2(-24.0, -8.0), Vector2(-44.0, -17.0), cloth, 4.0)
		draw_line(Vector2(-12.0, -8.0), Vector2(48.0, -8.0), Color(0.78, 0.83, 0.91, alpha), 2.0)
		return
	var body_color := Color(0.055, 0.065, 0.11)
	if hit_flash_timer > 0.0:
		body_color = Color("f5d5d5")
	elif invuln > 0.0 and int(Time.get_ticks_msec() / 80) % 2 == 0:
		body_color = Color(0.8, 0.8, 0.9)
	if parry_flash_timer > 0.0:
		body_color = Color("ffd36a")
	elif block_flash_timer > 0.0:
		body_color = Color("8bbcff")
	draw_rect(Rect2(-16, -12, 13, 12), Color("171a2a"))
	draw_rect(Rect2(3, -12, 14, 12), Color("171a2a"))
	draw_rect(Rect2(-13, -49 if not crouching else -38, 27, 38 if not crouching else 27), body_color)
	var gait := sin(animation_elapsed * 15.0)
	var leg_swing := gait * 8.0 if animation_state == "RUN" else 0.0
	var arm_swing := -gait * 7.0 if animation_state == "RUN" else 0.0
	if animation_state in ["JUMP", "FALL"]:
		leg_swing = -5.0 if animation_state == "JUMP" else 7.0
		arm_swing = -12.0 if animation_state == "JUMP" else 10.0
	elif animation_state == "DASH":
		leg_swing = -8.0
		arm_swing = -16.0
	elif animation_state == "GRAPPLE":
		leg_swing = sin(animation_elapsed * 5.0) * 9.0
		arm_swing = -22.0
	draw_line(Vector2(-7, -13), Vector2(-10 + leg_swing, -1), Color("171a2a"), 5.0)
	draw_line(Vector2(7, -13), Vector2(10 - leg_swing, -1), Color("171a2a"), 5.0)
	var arm_color := Color("b5bbc9") if animation_state == "BLOCK" else body_color.lightened(0.12)
	draw_line(Vector2(-10, -43), Vector2(-20 + arm_swing, -29), arm_color, 5.0)
	if animation_state in ["ATTACK_1", "ATTACK_2", "ATTACK_3"]:
		var sword_ready_y := -54.0 if attack_phase == "WINDUP" else -34.0
		draw_line(Vector2(10 * facing, -43), Vector2(25 * facing, sword_ready_y), Color("d6dcea"), 4.0)
	else:
		draw_line(Vector2(10, -43), Vector2(19 + arm_swing, -29), arm_color, 5.0)
	draw_rect(Rect2(-11, -66 if not crouching else -55, 23, 20), Color("20263c"))
	draw_rect(Rect2(-9, -61 if not crouching else -50, 19, 8), Color("090d19"))
	draw_rect(Rect2(2 if facing > 0 else -9, -57 if not crouching else -46, 8, 3), Color("e8e9f5"))
	var scarf := PackedVector2Array([Vector2(-8 * facing, -47), Vector2(-30 * facing, -40), Vector2(-48 * facing, -27), Vector2(-26 * facing, -35)])
	draw_colored_polygon(scarf, Color("a71936"))
	draw_line(Vector2(-5 * facing, -47), Vector2(-38 * facing, -40), Color("e43b52"), 3.0)
	if second_jump_flash_timer > 0.0:
		var effect_progress := second_jump_flash_timer / SECOND_JUMP_FLASH_TIME
		var effect_alpha := clampf(effect_progress, 0.0, 1.0)
		draw_arc(Vector2(0, -28), 31.0 + (1.0 - effect_progress) * 24.0, 0.0, TAU, 24, Color(0.48, 0.88, 1.0, effect_alpha), 3.0)
		draw_line(Vector2(-22, -10), Vector2(-38, 8), Color(0.66, 0.93, 1.0, effect_alpha), 3.0)
		draw_line(Vector2(22, -10), Vector2(38, 8), Color(0.66, 0.93, 1.0, effect_alpha), 3.0)
	if attacking and attack_phase == "WINDUP":
		draw_arc(Vector2(22 * facing, -40), 24.0, deg_to_rad(-70 if facing > 0 else 190), deg_to_rad(10 if facing > 0 else 270), 12, Color(0.82, 0.88, 1.0, 0.52), 2.0)
	if attack_active:
		var start := Vector2(13 * facing, -36)
		match current_attack_visual_style:
			"QUICK":
				# Strike 1: fast diagonal cut with a narrow pale trail.
				draw_line(start, Vector2(68 * facing, -68), Color("f4e7e4"), 4.0)
				draw_arc(start, 48, deg_to_rad(-72 if facing > 0 else 188), deg_to_rad(12 if facing > 0 else 282), 12, Color("dce6ff"), 3.0)
			"CROSS":
				# Strike 2: broad cross-cut, drawn as two crossing streaks.
				draw_line(Vector2(8 * facing, -64), Vector2(73 * facing, -20), Color("ffcf88"), 6.0)
				draw_line(Vector2(14 * facing, -18), Vector2(68 * facing, -66), Color("f4e7e4"), 3.0)
			"FINISHER":
				# Strike 3: heavy finisher with a wide bright arc and impact flare.
				draw_arc(Vector2(18 * facing, -38), 76, deg_to_rad(-82 if facing > 0 else 188), deg_to_rad(72 if facing > 0 else 352), 20, Color("ff6b76"), 9.0)
				draw_line(start, Vector2(100 * facing, -42), Color("fff0d0"), 8.0)
				draw_circle(Vector2(86 * facing, -42), 8.0, Color("ffd36a"))
	if block_held and not guard_is_broken:
		draw_arc(Vector2(18 * facing, -38), 43, deg_to_rad(-75 if facing > 0 else 195), deg_to_rad(75 if facing > 0 else 345), 18, Color("83baff"), 4.0)
	if grappling:
		var anchor_local := to_local(grapple_point)
		draw_line(Vector2(0, -48), anchor_local, Color(0.08, 0.11, 0.18, 0.85), 5.0)
		draw_line(Vector2(0, -48), anchor_local, Color("d4d7e5"), 2.4)
		draw_circle(anchor_local, 5.0, Color("f1d39a"))
		draw_arc(anchor_local, 13.0, 0.0, TAU, 20, Color("f1d39a", 0.88), 2.0)
	elif grapple_target != Vector2.ZERO:
		var target_local := to_local(grapple_target)
		draw_circle(target_local, 5.0, Color(0.52, 0.84, 0.86, 0.88))
		draw_arc(target_local, 17.0, 0.0, TAU, 24, Color(0.52, 0.84, 0.86, 0.72), 2.2)
