extends Node2D
class_name SilentBladeNoiseSystem

signal noise_emitted(event: Dictionary)

const EVENT_LIFETIME := 4.5
const VISUAL_LIFETIME := 0.72
const MAX_EVENTS := 24
const NOISE_EVENT_PROFILES := {
	"SNEAK_STEP": {"event_weight": 0.62, "priority": 1},
	"FOOTSTEP": {"event_weight": 1.0, "priority": 2},
	"JUMP": {"event_weight": 0.88, "priority": 2},
	"LAND": {"event_weight": 1.04, "priority": 3},
	"FALL": {"event_weight": 1.22, "priority": 4},
	"DASH": {"event_weight": 1.16, "priority": 4},
	"GRAPPLE": {"event_weight": 0.82, "priority": 2},
	"ATTACK": {"event_weight": 1.12, "priority": 3},
	"DECOY": {"event_weight": 1.20, "priority": 4},
	"INTERACTION": {"event_weight": 0.86, "priority": 2},
	"GLOBAL_ALARM": {"event_weight": 1.35, "priority": 5}
}
var active_events: Array[Dictionary] = []
var _next_event_id := 1
var _prune_timer := 0.0

func emit_noise(world_position: Vector2, radius: float, intensity: float, event_type: String, source_id: int = -1) -> void:
	var event_profile: Dictionary = NOISE_EVENT_PROFILES.get(event_type, {"event_weight": 1.0, "priority": 1})
	var event := {
		"id": _next_event_id,
		"position": world_position,
		"radius": maxf(0.0, radius),
		"intensity": clampf(intensity, 0.0, 1.0),
		"event_type": event_type,
		"event_weight": float(event_profile.get("event_weight", 1.0)),
		"priority": int(event_profile.get("priority", 1)),
		"source_id": source_id,
		"age": 0.0
	}
	_next_event_id += 1
	active_events.append(event)
	while active_events.size() > MAX_EVENTS:
		active_events.pop_front()
	noise_emitted.emit(event.duplicate())
	queue_redraw()

func _process(delta: float) -> void:
	_prune_timer -= delta
	var has_visual := false
	for event in active_events:
		event["age"] = float(event["age"]) + delta
		if float(event["age"]) <= VISUAL_LIFETIME:
			has_visual = true
	if _prune_timer <= 0.0:
		_prune_timer = 0.5
		for index in range(active_events.size() - 1, -1, -1):
			if float(active_events[index]["age"]) > EVENT_LIFETIME:
				active_events.remove_at(index)
	if has_visual:
		queue_redraw()

func _draw() -> void:
	for event in active_events:
		var age := float(event["age"])
		if age > VISUAL_LIFETIME:
			continue
		var progress := age / VISUAL_LIFETIME
		var radius := 12.0 + progress * minf(80.0, float(event["radius"]) * 0.18)
		var alpha := (1.0 - progress) * 0.5
		draw_arc(event["position"], radius, 0.0, TAU, 28, Color(0.95, 0.78, 0.42, alpha), 2.0)
