extends Node2D
class_name SilentBladeImpactEffect

const MAX_LIFETIME := 0.34

var effect_kind := "LIGHT"
var direction := 1
var lifetime := MAX_LIFETIME
var spark_positions: Array[Vector2] = []
var spark_velocities: Array[Vector2] = []

func configure(kind: String, facing: int = 1) -> void:
	effect_kind = kind
	direction = 1 if facing >= 0 else -1
	lifetime = MAX_LIFETIME
	spark_positions.clear()
	spark_velocities.clear()
	var speed := 145.0 if effect_kind == "HEAVY" else 108.0
	for index in range(7):
		var angle := TAU * float(index) / 7.0
		var radial := Vector2(cos(angle) * float(direction), sin(angle))
		spark_positions.append(Vector2.ZERO)
		spark_velocities.append(radial * speed + Vector2(float(direction) * 24.0, -18.0))
	queue_redraw()

func _process(delta: float) -> void:
	lifetime = maxf(0.0, lifetime - delta)
	if lifetime <= 0.0:
		queue_free()
		return
	for index in range(spark_positions.size()):
		spark_positions[index] += spark_velocities[index] * delta
		spark_velocities[index].y += 310.0 * delta
		spark_velocities[index] = spark_velocities[index].move_toward(Vector2.ZERO, 42.0 * delta)
	queue_redraw()

func _draw() -> void:
	var progress := clampf(lifetime / MAX_LIFETIME, 0.0, 1.0)
	var alpha := progress
	for index in range(spark_positions.size()):
		var spark_velocity: Vector2 = spark_velocities[index]
		var trail := spark_velocity.normalized() * 5.0
		var spark_color := Color(1.0, 0.78, 0.42, alpha) if effect_kind in ["HEAVY", "PARRY"] else Color(0.84, 0.91, 1.0, alpha)
		draw_line(spark_positions[index] - trail, spark_positions[index], spark_color, 1.8)
	match effect_kind:
		"PARRY":
			draw_arc(Vector2.ZERO, 22.0 + (1.0 - progress) * 28.0, 0.0, TAU, 36, Color(1.0, 0.82, 0.36, alpha), 4.0)
			draw_line(Vector2(-17, -17), Vector2(17, 17), Color(0.88, 0.95, 1.0, alpha), 3.0)
			draw_line(Vector2(-17, 17), Vector2(17, -17), Color(0.88, 0.95, 1.0, alpha), 3.0)
		"HEAVY":
			draw_arc(Vector2.ZERO, 13.0 + (1.0 - progress) * 34.0, 0.0, TAU, 32, Color(1.0, 0.36, 0.38, alpha), 4.0)
			draw_colored_polygon(PackedVector2Array([Vector2(0, -19), Vector2(6, -5), Vector2(20, 0), Vector2(6, 5), Vector2(0, 19), Vector2(-6, 5), Vector2(-20, 0), Vector2(-6, -5)]), Color(1.0, 0.79, 0.45, alpha * 0.72))
		"GUARD":
			draw_arc(Vector2.ZERO, 21.0, deg_to_rad(-65), deg_to_rad(65), 20, Color(0.53, 0.78, 1.0, alpha), 5.0)
		"HIT":
			draw_circle(Vector2.ZERO, 8.0 + (1.0 - progress) * 10.0, Color(1.0, 0.27, 0.38, alpha * 0.26))
			draw_arc(Vector2.ZERO, 14.0 + (1.0 - progress) * 18.0, 0.0, TAU, 24, Color(1.0, 0.58, 0.58, alpha), 2.5)
		_:
			for index in range(6):
				var angle := TAU * float(index) / 6.0 + float(direction) * 0.2
				var start := Vector2(cos(angle), sin(angle)) * 5.0
				var finish := Vector2(cos(angle), sin(angle)) * (14.0 + (1.0 - progress) * 16.0)
				draw_line(start, finish, Color(0.94, 0.89, 0.76, alpha), 2.0)
