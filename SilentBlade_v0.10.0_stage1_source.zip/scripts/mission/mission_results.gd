extends RefCounted
class_name SilentBladeMissionResults

# Fixed v0.9 score rubric: transparent deductions and bonuses out of 1000 points.
const S_SCORE_THRESHOLD := 920
const A_SCORE_THRESHOLD := 820
const B_SCORE_THRESHOLD := 680
const BEST_RESULTS_PATH := "user://silent_blade_records.cfg"

static func score(stats: Dictionary) -> int:
	if not bool(stats.get("success", false)):
		return 0
	var value := 1000
	var elapsed := maxf(0.0, float(stats.get("elapsed_time", 0.0)))
	value -= clampi(int(maxf(0.0, elapsed - 420.0) * 0.25), 0, 180)
	value -= mini(360, int(stats.get("detections", 0)) * 90)
	value -= mini(260, int(stats.get("alarms", 0)) * 65)
	value -= mini(120, int(float(stats.get("damage_taken", 0.0)) * 0.70))
	value -= mini(100, int(stats.get("neutralized", 0)) * 20)
	var missing_secrets := maxi(0, int(stats.get("secrets_total", 0)) - int(stats.get("secrets_found", 0)))
	value -= missing_secrets * 35
	var missing_documents := maxi(0, int(stats.get("documents_total", 2)) - int(stats.get("documents_collected", 0)))
	value -= missing_documents * 50
	var optional_done := _count_completed_optional(stats)
	value += mini(80, optional_done * 20)
	var attacks := maxi(0, int(stats.get("attacks", 0)))
	var hits_landed := clampi(int(stats.get("hits_landed", 0)), 0, attacks)
	var accuracy_bonus := int(round(30.0 * float(hits_landed) / float(attacks))) if attacks > 0 else 0
	var parry_bonus := mini(40, maxi(0, int(stats.get("parries", 0))) * 8)
	value += accuracy_bonus + parry_bonus
	return clampi(value, 0, 1000)

static func evaluate(stats: Dictionary) -> String:
	if not bool(stats.get("success", false)):
		return "D"
	var points := score(stats)
	if points >= S_SCORE_THRESHOLD:
		return "S"
	if points >= A_SCORE_THRESHOLD:
		return "A"
	if points >= B_SCORE_THRESHOLD:
		return "B"
	return "C"

static func explain(stats: Dictionary) -> Array[String]:
	var lines: Array[String] = []
	if not bool(stats.get("success", false)):
		return ["Миссия не завершена: ранг D."]
	var elapsed := maxf(0.0, float(stats.get("elapsed_time", 0.0)))
	var time_penalty := clampi(int(maxf(0.0, elapsed - 420.0) * 0.25), 0, 180)
	lines.append("Время: %s (штраф %d)" % [_format_time(elapsed), time_penalty])
	lines.append("Обнаружения: %d (−%d)" % [int(stats.get("detections", 0)), mini(360, int(stats.get("detections", 0)) * 90)])
	lines.append("Тревоги: %d (−%d)" % [int(stats.get("alarms", 0)), mini(260, int(stats.get("alarms", 0)) * 65)])
	lines.append("Полученный урон: %.0f (−%d)" % [float(stats.get("damage_taken", 0.0)), mini(120, int(float(stats.get("damage_taken", 0.0)) * 0.70))])
	lines.append("Нейтрализации: %d (−%d)" % [int(stats.get("neutralized", 0)), mini(100, int(stats.get("neutralized", 0)) * 20)])
	var missing_secrets := maxi(0, int(stats.get("secrets_total", 0)) - int(stats.get("secrets_found", 0)))
	var missing_documents := maxi(0, int(stats.get("documents_total", 2)) - int(stats.get("documents_collected", 0)))
	lines.append("Секреты: %d/%d (−%d)" % [int(stats.get("secrets_found", 0)), int(stats.get("secrets_total", 0)), missing_secrets * 35])
	lines.append("Документы: %d/%d (−%d)" % [int(stats.get("documents_collected", 0)), int(stats.get("documents_total", 2)), missing_documents * 50])
	var attacks := maxi(0, int(stats.get("attacks", 0)))
	var hits_landed := clampi(int(stats.get("hits_landed", 0)), 0, attacks)
	var accuracy_bonus := int(round(30.0 * float(hits_landed) / float(attacks))) if attacks > 0 else 0
	var parry_bonus := mini(40, maxi(0, int(stats.get("parries", 0))) * 8)
	lines.append("Боевые действия: %d атак, %d попаданий, %d получено (получено урона %.0f)" % [attacks, hits_landed, int(stats.get("hits_taken", 0)), float(stats.get("damage_taken", 0.0))])
	lines.append("Комбо-точность: %d/%d (+%d)" % [hits_landed, attacks, accuracy_bonus])
	lines.append("Парирования: %d (+%d)" % [int(stats.get("parries", 0)), parry_bonus])
	var optional_done := _count_completed_optional(stats)
	lines.append("Дополнительные задания: %d/4 (+%d)" % [optional_done, mini(80, optional_done * 20)])
	return lines

static func _count_completed_optional(stats: Dictionary) -> int:
	var completed := 0
	for task in optional_objectives(stats):
		if bool(task.get("completed", false)):
			completed += 1
	return completed

static func load_best(mission_id: String) -> Dictionary:
	if mission_id.is_empty():
		return {}
	var config := ConfigFile.new()
	var err := config.load(BEST_RESULTS_PATH)
	if err != OK:
		return {}
	var stored: Variant = config.get_value("best", mission_id, {})
	return stored.duplicate(true) if stored is Dictionary else {}

static func save_best(mission_id: String, result: Dictionary) -> bool:
	if mission_id.is_empty() or not bool(result.get("success", false)):
		return false
	var new_score := int(result.get("score", score(result)))
	var old_result := load_best(mission_id)
	var old_score := int(old_result.get("score", -1))
	var new_time := float(result.get("elapsed_time", 1.0e12))
	var old_time := float(old_result.get("elapsed_time", 1.0e12))
	if new_score < old_score or (new_score == old_score and new_time >= old_time):
		return false
	var config := ConfigFile.new()
	var load_error := config.load(BEST_RESULTS_PATH)
	if load_error != OK and load_error != ERR_FILE_NOT_FOUND:
		return false
	var compact_result := {
		"rank": String(result.get("rank", evaluate(result))),
		"score": new_score,
		"elapsed_time": new_time,
		"detections": int(result.get("detections", 0)),
		"alarms": int(result.get("alarms", 0)),
		"neutralized": int(result.get("neutralized", 0)),
		"attacks": int(result.get("attacks", 0)),
		"hits_landed": int(result.get("hits_landed", 0)),
		"hits_taken": int(result.get("hits_taken", 0)),
		"parries": int(result.get("parries", 0)),
		"damage_taken": float(result.get("damage_taken", 0.0)),
		"grapple_uses": int(result.get("grapple_uses", 0)),
		"distractions_used": int(result.get("distractions_used", 0)),
		"secrets_found": int(result.get("secrets_found", 0)),
		"documents_collected": int(result.get("documents_collected", 0))
	}
	config.set_value("best", mission_id, compact_result)
	return config.save(BEST_RESULTS_PATH) == OK

static func optional_objectives(stats: Dictionary) -> Array[Dictionary]:
	var detection_free := int(stats.get("detections", 0)) == 0
	var no_kills := int(stats.get("neutralized", 0)) == 0
	var all_secrets := int(stats.get("secrets_found", 0)) >= int(stats.get("secrets_total", 0))
	var all_documents := int(stats.get("documents_collected", 0)) >= int(stats.get("documents_total", 2))
	return [
		{"id": "ghost_run", "title": "Призрак: пройти без обнаружения", "completed": detection_free},
		{"id": "no_kills", "title": "Без кровопролития: не устранять противников", "completed": no_kills},
		{"id": "all_secrets", "title": "Собиратель: найти все секреты", "completed": all_secrets},
		{"id": "all_documents", "title": "Архивариус: собрать оба документа", "completed": all_documents}
	]

static func _format_time(seconds: float) -> String:
	var total := int(seconds)
	return "%02d:%02d" % [total / 60, total % 60]
