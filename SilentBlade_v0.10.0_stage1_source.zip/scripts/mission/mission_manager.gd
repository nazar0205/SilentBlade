extends Node
class_name SilentBladeMissionManager

signal objective_changed(current: Dictionary, completed_count: int, total_count: int)
signal stats_changed(stats: Dictionary)
signal mission_completed(results: Dictionary)
signal mission_failed(results: Dictionary)

const ObjectiveManagerScript = preload("res://scripts/mission/objective_manager.gd")
const MissionResultsScript = preload("res://scripts/mission/mission_results.gd")

var mission_config: Dictionary = {}
var objective_manager: SilentBladeObjectiveManager
var optional_objectives: Array[Dictionary] = []
var secret_definitions: Array[Dictionary] = []
var collected_item_ids: Dictionary = {}
var world_flags: Dictionary = {}
var elapsed_time := 0.0
var detections := 0
var alarms := 0
var secrets_found := 0
var neutralized := 0
var documents_collected := 0
var attacks := 0
var hits_landed := 0
var parries := 0
var damage_taken := 0.0
var hits_taken := 0
var grapple_uses := 0
var distractions_used := 0
var mission_started := false
var is_finished := false
var is_success := false
var failure_reason := ""

func _ready() -> void:
	objective_manager = ObjectiveManagerScript.new()
	objective_manager.progress_changed.connect(_on_objective_progress)

func start_mission(config: Dictionary) -> void:
	mission_config = config.duplicate(true)
	if objective_manager == null:
		objective_manager = ObjectiveManagerScript.new()
		objective_manager.progress_changed.connect(_on_objective_progress)
	objective_manager.configure(mission_config.get("objectives", []))
	optional_objectives.clear()
	for entry in mission_config.get("optional_objectives", []):
		if entry is Dictionary:
			optional_objectives.append(entry.duplicate(true))
	secret_definitions.clear()
	for entry in mission_config.get("secrets", []):
		if entry is Dictionary:
			secret_definitions.append(entry.duplicate(true))
	collected_item_ids.clear()
	world_flags.clear()
	elapsed_time = 0.0
	detections = 0
	alarms = 0
	secrets_found = 0
	neutralized = 0
	documents_collected = 0
	attacks = 0
	hits_landed = 0
	parries = 0
	damage_taken = 0.0
	hits_taken = 0
	grapple_uses = 0
	distractions_used = 0
	mission_started = false
	is_finished = false
	is_success = false
	failure_reason = ""

func begin_clock() -> void:
	mission_started = true

func tick(delta: float) -> void:
	if mission_started and not is_finished:
		elapsed_time += maxf(0.0, delta)

func complete_objective(objective_id: String) -> bool:
	if is_finished or objective_manager == null:
		return false
	return objective_manager.complete(objective_id)

func is_objective_completed(objective_id: String) -> bool:
	return objective_manager != null and objective_manager.is_completed(objective_id)

func collect_item(item_id: String, item_kind: String) -> bool:
	if is_finished or item_id.is_empty() or collected_item_ids.has(item_id):
		return false
	collected_item_ids[item_id] = item_kind
	if item_kind == "SECRET" or item_kind == "CACHE":
		secrets_found += 1
	elif item_kind == "DOCUMENT":
		documents_collected += 1
		if item_id != "archive_orders":
			secrets_found += 1
	stats_changed.emit(get_stats())
	return true

func has_collected(item_id: String) -> bool:
	return collected_item_ids.has(item_id)

func set_world_flag(flag_id: String, value: bool = true) -> void:
	world_flags[flag_id] = value
	stats_changed.emit(get_stats())

func has_world_flag(flag_id: String) -> bool:
	return bool(world_flags.get(flag_id, false))

func record_detection() -> void:
	record_event("detections")

func record_alarm() -> void:
	record_event("alarms")

func record_neutralization() -> void:
	record_event("neutralized")

func record_event(event_name: String, amount: float = 1.0) -> void:
	if is_finished or amount <= 0.0:
		return
	match event_name:
		"detections": detections += int(round(amount))
		"alarms": alarms += int(round(amount))
		"neutralized": neutralized += int(round(amount))
		"attacks": attacks += int(round(amount))
		"hits_landed": hits_landed += int(round(amount))
		"parries": parries += int(round(amount))
		"damage_taken": damage_taken += amount
		"hits_taken": hits_taken += int(round(amount))
		"grapple_uses": grapple_uses += int(round(amount))
		"distractions_used": distractions_used += int(round(amount))
		_: return
	stats_changed.emit(get_stats())

func get_optional_results() -> Array[Dictionary]:
	return MissionResultsScript.optional_objectives(get_stats())

func get_stats() -> Dictionary:
	var extra_documents := 0
	for secret in secret_definitions:
		if String(secret.get("kind", "")) == "DOCUMENT":
			extra_documents += 1
	return {
		"elapsed_time": elapsed_time,
		"documents_total": 1 + extra_documents,
		"detections": detections,
		"alarms": alarms,
		"secrets_found": secrets_found,
		"secrets_total": secret_definitions.size(),
		"documents_collected": documents_collected,
		"neutralized": neutralized,
		"attacks": attacks,
		"hits_landed": hits_landed,
		"parries": parries,
		"damage_taken": damage_taken,
		"hits_taken": hits_taken,
		"grapple_uses": grapple_uses,
		"distractions_used": distractions_used,
		"collected_ids": collected_item_ids.keys(),
		"completed_objectives": objective_manager.get_completed_ids() if objective_manager else []
	}

func get_results(success: bool) -> Dictionary:
	var stats := get_stats()
	stats["success"] = success
	var rank := MissionResultsScript.evaluate(stats)
	var optional_done := MissionResultsScript.optional_objectives(stats)
	var time_seconds := int(elapsed_time)
	var results := {
		"mission_title": String(mission_config.get("title", "MISSION 01")),
		"success": success,
		"rank": rank,
		"elapsed_time": elapsed_time,
		"time_text": "%02d:%02d" % [time_seconds / 60, time_seconds % 60],
		"detections": detections,
		"alarms": alarms,
		"secrets_found": secrets_found,
		"secrets_total": secret_definitions.size(),
		"documents_collected": documents_collected,
		"neutralized": neutralized,
		"attacks": attacks,
		"hits_landed": hits_landed,
		"parries": parries,
		"damage_taken": damage_taken,
		"hits_taken": hits_taken,
		"grapple_uses": grapple_uses,
		"distractions_used": distractions_used,
		"score": MissionResultsScript.score(stats),
		"score_reasons": MissionResultsScript.explain(stats),
		"optional_completed": optional_done,
		"optional_total": optional_objectives.size(),
		"completed_objectives": objective_manager.get_completed_ids() if objective_manager else []
	}
	return results

func finish_mission(success: bool, reason: String = "") -> Dictionary:
	if is_finished:
		return get_results(is_success)
	is_finished = true
	is_success = success
	failure_reason = reason
	var results := get_results(success)
	var mission_id := String(mission_config.get("id", "mission_01_shadow_of_the_village"))
	var previous_best := MissionResultsScript.load_best(mission_id)
	results["previous_best"] = previous_best
	results["new_record"] = false
	if success:
		results["new_record"] = MissionResultsScript.save_best(mission_id, results)
		mission_completed.emit(results)
	else:
		mission_failed.emit(results)
	return results

func restore_persistent_state(completed_ids: Array, collected_ids: Dictionary, flags: Dictionary, saved_stats: Dictionary) -> void:
	if objective_manager:
		objective_manager.restore_completed(completed_ids)
	collected_item_ids = collected_ids.duplicate(true)
	world_flags = flags.duplicate(true)
	secrets_found = int(saved_stats.get("secrets_found", 0))
	documents_collected = int(saved_stats.get("documents_collected", 0))
	detections = int(saved_stats.get("detections", detections))
	alarms = int(saved_stats.get("alarms", alarms))
	neutralized = int(saved_stats.get("neutralized", neutralized))
	attacks = int(saved_stats.get("attacks", attacks))
	hits_landed = int(saved_stats.get("hits_landed", hits_landed))
	parries = int(saved_stats.get("parries", parries))
	damage_taken = float(saved_stats.get("damage_taken", damage_taken))
	hits_taken = int(saved_stats.get("hits_taken", hits_taken))
	grapple_uses = int(saved_stats.get("grapple_uses", grapple_uses))
	distractions_used = int(saved_stats.get("distractions_used", distractions_used))
	elapsed_time = float(saved_stats.get("elapsed_time", elapsed_time))
	stats_changed.emit(get_stats())

func restore_progress_state(snapshot: Dictionary) -> void:
	if objective_manager:
		var completed_union := objective_manager.get_completed_ids()
		for objective_id in snapshot.get("completed_objectives", []):
			if not completed_union.has(String(objective_id)):
				completed_union.append(String(objective_id))
		objective_manager.restore_completed(completed_union)
	for item_id in snapshot.get("collected_item_ids", {}):
		if not collected_item_ids.has(item_id):
			collected_item_ids[item_id] = snapshot["collected_item_ids"][item_id]
	for flag_id in snapshot.get("world_flags", {}):
		if bool(snapshot["world_flags"][flag_id]):
			world_flags[flag_id] = true
	var saved_stats: Dictionary = snapshot.get("stats", {})
	# Run counters are monotonic: a death may restore progress but never rewinds elapsed time or penalties.
	elapsed_time = maxf(elapsed_time, float(saved_stats.get("elapsed_time", 0.0)))
	detections = maxi(detections, int(saved_stats.get("detections", 0)))
	alarms = maxi(alarms, int(saved_stats.get("alarms", 0)))
	neutralized = maxi(neutralized, int(saved_stats.get("neutralized", 0)))
	attacks = maxi(attacks, int(saved_stats.get("attacks", 0)))
	hits_landed = maxi(hits_landed, int(saved_stats.get("hits_landed", 0)))
	parries = maxi(parries, int(saved_stats.get("parries", 0)))
	damage_taken = maxf(damage_taken, float(saved_stats.get("damage_taken", 0.0)))
	hits_taken = maxi(hits_taken, int(saved_stats.get("hits_taken", 0)))
	grapple_uses = maxi(grapple_uses, int(saved_stats.get("grapple_uses", 0)))
	distractions_used = maxi(distractions_used, int(saved_stats.get("distractions_used", 0)))
	stats_changed.emit(get_stats())

func snapshot_persistent_state() -> Dictionary:
	return {
		"completed_objectives": objective_manager.get_completed_ids() if objective_manager else [],
		"collected_item_ids": collected_item_ids.duplicate(true),
		"world_flags": world_flags.duplicate(true),
		"stats": get_stats()
	}

func _on_objective_progress(current: Dictionary, completed_count: int, total_count: int) -> void:
	objective_changed.emit(current, completed_count, total_count)
