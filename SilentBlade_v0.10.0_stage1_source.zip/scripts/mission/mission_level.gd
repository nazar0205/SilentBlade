extends Node2D
class_name SilentBladeMissionLevel

const StealthZoneScript = preload("res://scripts/stealth/stealth_zone.gd")
const MissionInteractableScript = preload("res://scripts/mission/mission_interactable.gd")

var enemy_spawns: Array[Dictionary] = []
var grapple_anchors: Array[Vector2] = []
var interactables: Array[SilentBladeMissionInteractable] = []
var world_width := 6200.0
var _leaves: Array[Dictionary] = []
var _leaf_refresh := 0.0

func build(stealth_system: SilentBladeStealthSystem) -> void:
	var config := _load_mission_data()
	world_width = float(config.get("world_width", 6200.0))
	for entry in config.get("enemy_spawns", []):
		if entry is Dictionary:
			enemy_spawns.append(entry.duplicate(true))
	grapple_anchors.clear()
	for anchor in config.get("grapple_anchors", []):
		if anchor is Dictionary:
			grapple_anchors.append(Vector2(float(anchor.get("x", 0.0)), float(anchor.get("y", 0.0))))
	_build_parallax()
	_build_geometry(config)
	_build_dressing()
	_build_stealth_environment(stealth_system)
	_build_interactables()
	for index in range(18):
		_leaves.append({"position": Vector2(randf_range(0.0, world_width), randf_range(100.0, 520.0)), "speed": randf_range(12.0, 29.0), "sway": randf_range(7.0, 21.0), "phase": randf_range(0.0, TAU)})
	queue_redraw()

func _load_mission_data() -> Dictionary:
	var path := "res://data/missions/mission_01.json"
	if not FileAccess.file_exists(path):
		push_error("Mission data missing: %s" % path)
		return {}
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(path))
	if not parsed is Dictionary:
		push_error("Mission data must be a JSON object")
		return {}
	return parsed

func _build_geometry(config: Dictionary) -> void:
	# Mission JSON is the single source of truth for all physical route surfaces.
	for entry in config.get("platforms", []):
		if not entry is Dictionary:
			continue
		var center := Vector2(float(entry.get("x", 0.0)), float(entry.get("y", 0.0)))
		var platform_size := Vector2(float(entry.get("width", 0.0)), float(entry.get("height", 0.0)))
		if platform_size.x <= 0.0 or platform_size.y <= 0.0:
			push_warning("Skipping invalid mission platform: %s" % String(entry.get("id", "unnamed")))
			continue
		_add_platform(center, platform_size, Color(String(entry.get("color", "242536"))))

func _build_dressing() -> void:
	for pos in [Vector2(170, 650), Vector2(470, 650), Vector2(820, 650), Vector2(1130, 650), Vector2(1530, 650), Vector2(1900, 650), Vector2(2320, 650), Vector2(2740, 650), Vector2(3150, 650), Vector2(3560, 650), Vector2(3890, 650), Vector2(4310, 650), Vector2(4680, 650), Vector2(5050, 650), Vector2(5480, 650), Vector2(5920, 650)]:
		_add_lantern(pos)
	for pos in [Vector2(1330, 650), Vector2(1820, 650), Vector2(3900, 650), Vector2(4520, 650), Vector2(5480, 650)]:
		_add_house(pos)
	_add_watch_tower(Vector2(3065, 650))
	_add_archive_facade(Vector2(4210, 650))
	for pos in [Vector2(320, 650), Vector2(500, 650), Vector2(1010, 650), Vector2(2170, 650), Vector2(2540, 650), Vector2(3420, 650), Vector2(4770, 650), Vector2(5530, 650)]:
		_add_bamboo_cluster(pos)

func _build_stealth_environment(stealth_system: SilentBladeStealthSystem) -> void:
	_add_stealth_zone(stealth_system, "GRASS", Vector2(440, 610), Vector2(280, 96))
	_add_stealth_zone(stealth_system, "GRASS", Vector2(1010, 610), Vector2(180, 94))
	_add_stealth_zone(stealth_system, "GRASS", Vector2(2180, 610), Vector2(220, 92))
	_add_stealth_zone(stealth_system, "GRASS", Vector2(2760, 610), Vector2(240, 94))
	_add_stealth_zone(stealth_system, "GRASS", Vector2(4840, 610), Vector2(260, 94))
	_add_stealth_zone(stealth_system, "GRASS", Vector2(5580, 610), Vector2(220, 94))
	_add_stealth_zone(stealth_system, "DARK", Vector2(780, 590), Vector2(250, 122))
	_add_stealth_zone(stealth_system, "DARK", Vector2(1760, 585), Vector2(250, 122))
	_add_stealth_zone(stealth_system, "DARK", Vector2(2500, 590), Vector2(240, 120))
	_add_stealth_zone(stealth_system, "DARK", Vector2(3600, 590), Vector2(240, 120))
	_add_stealth_zone(stealth_system, "DARK", Vector2(4770, 590), Vector2(220, 118))
	_add_stealth_zone(stealth_system, "LIGHT", Vector2(1300, 590), Vector2(180, 150))
	_add_stealth_zone(stealth_system, "LIGHT", Vector2(2380, 590), Vector2(210, 150))
	_add_stealth_zone(stealth_system, "LIGHT", Vector2(3160, 590), Vector2(220, 150))
	_add_stealth_zone(stealth_system, "LIGHT", Vector2(4250, 590), Vector2(240, 150))
	_add_stealth_zone(stealth_system, "LIGHT", Vector2(5350, 590), Vector2(190, 142))
	_add_cover_obstacle(Vector2(870, 605), Vector2(58, 86))
	_add_cover_obstacle(Vector2(1560, 605), Vector2(66, 84))
	_add_cover_obstacle(Vector2(2630, 605), Vector2(60, 86))
	_add_cover_obstacle(Vector2(3580, 605), Vector2(58, 82))
	_add_cover_obstacle(Vector2(4620, 605), Vector2(62, 86))
	_add_cover_obstacle(Vector2(5420, 605), Vector2(62, 84))
	_add_stealth_zone(stealth_system, "COVER", Vector2(870, 605), Vector2(136, 136))
	_add_stealth_zone(stealth_system, "COVER", Vector2(1560, 605), Vector2(142, 134))
	_add_stealth_zone(stealth_system, "COVER", Vector2(2630, 605), Vector2(136, 136))
	_add_stealth_zone(stealth_system, "COVER", Vector2(3580, 605), Vector2(132, 132))
	_add_stealth_zone(stealth_system, "COVER", Vector2(4620, 605), Vector2(138, 136))
	_add_stealth_zone(stealth_system, "COVER", Vector2(5420, 605), Vector2(138, 134))

func _build_interactables() -> void:
	_add_interactable("village_gate", "door", "ОТКРЫТЬ", false, Vector2(2280, 650))
	_add_interactable("hidden_passage", "door", "ОТКРЫТЬ", false, Vector2(3560, 650), "signal_disabled", "ОТКЛЮЧИТЕ СИГНАЛ")
	_add_interactable("signal_console", "alarm", "ОТКЛЮЧИТЬ", true, Vector2(3210, 610))
	_add_interactable("hidden_cache", "cache", "ТАЙНИК", true, Vector2(1650, 328))
	_add_interactable("field_report", "document", "ЗАПИСКА", true, Vector2(3020, 355))
	_add_interactable("archive_side_door", "door", "ОТКРЫТЬ", false, Vector2(4210, 650))
	_add_interactable("archive_orders", "archive", "ЗАБРАТЬ", true, Vector2(4260, 585))
	_add_interactable("village_checkpoint", "checkpoint", "СОХРАНИТЬ", true, Vector2(2160, 615))
	_add_interactable("archive_checkpoint", "checkpoint", "СОХРАНИТЬ", true, Vector2(3940, 615))
	_add_interactable("evacuation_exit", "evacuation", "ЭВАКУАЦИЯ", false, Vector2(5760, 610), "mission_ready_for_evacuation", "ЗАБЕРИТЕ ПЛАНЫ И ОТКЛЮЧИТЕ СИГНАЛ")

func _add_interactable(id: String, object_kind: String, action_prompt: String, one_shot: bool, pos: Vector2, needs_flag: String = "", locked_text: String = "ЗАКРЫТО") -> void:
	var prop: SilentBladeMissionInteractable = MissionInteractableScript.new()
	prop.name = "Interact_%s" % id
	prop.configure(id, object_kind, action_prompt, one_shot, needs_flag, locked_text)
	prop.position = pos
	add_child(prop)
	interactables.append(prop)

func _add_stealth_zone(stealth_system: SilentBladeStealthSystem, kind: String, center: Vector2, size: Vector2) -> void:
	var zone: SilentBladeStealthZone = StealthZoneScript.new()
	zone.name = "%s_Zone" % kind
	zone.zone_type = kind
	zone.zone_size = size
	zone.position = center
	var shape := CollisionShape2D.new()
	var rectangle := RectangleShape2D.new()
	rectangle.size = size
	shape.shape = rectangle
	zone.add_child(shape)
	add_child(zone)
	stealth_system.register_zone(zone)

func _add_cover_obstacle(center: Vector2, size: Vector2) -> void:
	var body := StaticBody2D.new()
	body.name = "OpaqueCover"
	body.position = center
	body.collision_layer = 1
	body.collision_mask = 1
	var shape := CollisionShape2D.new()
	var rect := RectangleShape2D.new()
	rect.size = size
	shape.shape = rect
	body.add_child(shape)
	var art := Polygon2D.new()
	art.polygon = PackedVector2Array([Vector2(-size.x * 0.5, -size.y * 0.5), Vector2(size.x * 0.5, -size.y * 0.5), Vector2(size.x * 0.5, size.y * 0.5), Vector2(-size.x * 0.5, size.y * 0.5)])
	art.color = Color("594331")
	body.add_child(art)
	var plank := Line2D.new()
	plank.points = PackedVector2Array([Vector2(-size.x * 0.42, -size.y * 0.08), Vector2(size.x * 0.42, -size.y * 0.08)])
	plank.default_color = Color("b18a5c")
	plank.width = 4.0
	body.add_child(plank)
	add_child(body)

func _add_platform(center: Vector2, size: Vector2, color: Color) -> void:
	var body := StaticBody2D.new()
	body.position = center
	body.collision_layer = 1
	body.collision_mask = 1
	var shape := CollisionShape2D.new()
	var rect := RectangleShape2D.new()
	rect.size = size
	shape.shape = rect
	body.add_child(shape)
	var art := Polygon2D.new()
	art.polygon = PackedVector2Array([Vector2(-size.x * 0.5, -size.y * 0.5), Vector2(size.x * 0.5, -size.y * 0.5), Vector2(size.x * 0.5, size.y * 0.5), Vector2(-size.x * 0.5, size.y * 0.5)])
	art.color = color
	body.add_child(art)
	var trim := Line2D.new()
	trim.points = PackedVector2Array([Vector2(-size.x * 0.5, -size.y * 0.5), Vector2(size.x * 0.5, -size.y * 0.5)])
	trim.default_color = Color("c6a879")
	trim.width = 4.0
	body.add_child(trim)
	add_child(body)

func _add_house(pos: Vector2) -> void:
	var node := Node2D.new()
	node.position = pos
	node.z_index = -2
	add_child(node)
	# Opaque lower wall: stops the player and vision rays but remains below the roof route.
	var wall := StaticBody2D.new()
	wall.name = "HouseWallCollision"
	wall.position = Vector2(0.0, -67.5)
	wall.collision_layer = 1
	wall.collision_mask = 1
	var wall_shape := CollisionShape2D.new()
	var wall_rect := RectangleShape2D.new()
	wall_rect.size = Vector2(178.0, 135.0)
	wall_shape.shape = wall_rect
	wall.add_child(wall_shape)
	node.add_child(wall)
	node.draw.connect(func():
		node.draw_rect(Rect2(-105, -210, 210, 210), Color("171d34"))
		node.draw_colored_polygon(PackedVector2Array([Vector2(-130, -210), Vector2(0, -295), Vector2(130, -210)]), Color("101629"))
		node.draw_line(Vector2(-125, -208), Vector2(125, -208), Color("6d4b48"), 9.0)
		for wx in [-60, 0, 60]:
			node.draw_rect(Rect2(wx - 12, -165, 24, 48), Color("db8742"))
		node.draw_rect(Rect2(-18, -70, 36, 70), Color("0c1224"))
	)

func _add_lantern(pos: Vector2) -> void:
	var node := Node2D.new()
	node.position = pos
	node.z_index = -1
	add_child(node)
	node.draw.connect(func():
		node.draw_line(Vector2(0, -68), Vector2(0, -5), Color("28253b"), 3.0)
		node.draw_rect(Rect2(-10, -36, 20, 30), Color("e99a45"))
		node.draw_rect(Rect2(-7, -33, 14, 24), Color("ffd18a"))
		node.draw_circle(Vector2(0, -21), 31, Color(1.0, 0.53, 0.18, 0.08))
	)

func _add_bamboo_cluster(pos: Vector2) -> void:
	var node := Node2D.new()
	node.position = pos
	node.z_index = -1
	add_child(node)
	node.draw.connect(func():
		for stalk in range(5):
			var x := float(stalk - 2) * 17.0
			var height := 105.0 + float((stalk * 23) % 55)
			node.draw_line(Vector2(x, -5), Vector2(x + sin(float(stalk)) * 10.0, -height), Color("29483f"), 5.0)
			for segment in range(1, 4):
				var y := -height * float(segment) / 4.0
				node.draw_line(Vector2(x - 4, y), Vector2(x + 5, y), Color("66805b"), 2.0)
			node.draw_line(Vector2(x, -height * 0.65), Vector2(x - 27, -height * 0.83), Color("456e56"), 4.0)
			node.draw_line(Vector2(x, -height * 0.48), Vector2(x + 24, -height * 0.67), Color("456e56"), 4.0)
	)

func _add_watch_tower(pos: Vector2) -> void:
	var node := Node2D.new()
	node.position = pos
	node.z_index = -1
	add_child(node)
	node.draw.connect(func():
		node.draw_rect(Rect2(-58, -292, 116, 292), Color("211d2c"))
		node.draw_rect(Rect2(-72, -306, 144, 24), Color("654451"))
		node.draw_colored_polygon(PackedVector2Array([Vector2(-84, -306), Vector2(0, -370), Vector2(84, -306)]), Color("151a29"))
		for x in [-34.0, 0.0, 34.0]:
			node.draw_rect(Rect2(x - 8, -260, 16, 38), Color("c77b44"))
	)

func _add_archive_facade(pos: Vector2) -> void:
	var node := Node2D.new()
	node.position = pos
	node.z_index = -2
	add_child(node)
	# Two opaque wall sections leave a 158 px doorway for the existing door interactable.
	for local_x in [-112.0, 112.0]:
		var wall := StaticBody2D.new()
		wall.name = "ArchiveWall_%s" % ("Left" if local_x < 0.0 else "Right")
		wall.position = Vector2(local_x, -110.0)
		wall.collision_layer = 1
		wall.collision_mask = 1
		var wall_shape := CollisionShape2D.new()
		var wall_rect := RectangleShape2D.new()
		wall_rect.size = Vector2(66.0, 220.0)
		wall_shape.shape = wall_rect
		wall.add_child(wall_shape)
		node.add_child(wall)
	node.draw.connect(func():
		node.draw_rect(Rect2(-145, -245, 290, 245), Color("181c2d"))
		node.draw_colored_polygon(PackedVector2Array([Vector2(-175, -245), Vector2(0, -340), Vector2(175, -245)]), Color("351f30"))
		node.draw_line(Vector2(-165, -243), Vector2(165, -243), Color("b74c56"), 10.0)
		node.draw_rect(Rect2(-38, -125, 76, 125), Color("2f202b"))
		node.draw_rect(Rect2(-26, -113, 52, 104), Color("ad754e"))
		for y in [-190.0, -160.0, -130.0]:
			node.draw_line(Vector2(-105, y), Vector2(-60, y), Color("b68a63"), 5.0)
			node.draw_line(Vector2(60, y), Vector2(105, y), Color("b68a63"), 5.0)
	)

func _build_parallax() -> void:
	# Five supplied Bamboo Forest panoramas. These are visual-only Parallax2D layers:
	# no collision bodies or gameplay surfaces are created from background art.
	# Scroll factors are tuned so each 4096px panorama covers a 1600px-wide
	# expanded mobile viewport over the full 6200px mission camera travel.
	_add_bamboo_parallax_layer(
		"Sky",
		"res://assets/backgrounds/bamboo_forest/parallax/01_sky_moon_clouds.png",
		Vector2(0.08, 0.0), 1.0, -50, -64.0
	)
	_add_bamboo_parallax_layer(
		"Mountains",
		"res://assets/backgrounds/bamboo_forest/parallax/02_distant_mountains.png",
		Vector2(0.18, 0.0), 1.0, -40, 43.0
	)
	_add_bamboo_parallax_layer(
		"Forest",
		"res://assets/backgrounds/bamboo_forest/parallax/03_forest_cliffs_waterfalls.png",
		Vector2(0.32, 0.0), 1.0, -30, -250.0
	)
	_add_bamboo_parallax_layer(
		"Architecture",
		"res://assets/backgrounds/bamboo_forest/parallax/04_japanese_architecture.png",
		Vector2(0.36, 0.0), 1.0, -20, -280.0
	)
	_add_bamboo_parallax_layer(
		"Foreground",
		"res://assets/backgrounds/bamboo_forest/parallax/05_foreground_bamboo_rocks_grass.png",
		Vector2(0.38, 0.0), 1.0, -10, -645.0
	)

func _add_bamboo_parallax_layer(layer_name: String, texture_path: String, scroll_scale: Vector2, scale_value: float, depth: int, vertical_offset: float) -> void:
	var texture := load(texture_path) as Texture2D
	if texture == null:
		push_error("Bamboo Forest background could not be loaded: %s" % texture_path)
		return
	var parallax := Parallax2D.new()
	parallax.name = "Bamboo%sParallax" % layer_name
	parallax.scroll_scale = scroll_scale
	parallax.repeat_size = Vector2.ZERO
	parallax.repeat_times = 1
	parallax.z_index = depth
	var artwork := Sprite2D.new()
	artwork.name = "%sArtwork" % layer_name
	artwork.texture = texture
	artwork.centered = false
	artwork.position = Vector2.ZERO
	artwork.scale = Vector2(scale_value, scale_value)
	artwork.position.y = vertical_offset
	artwork.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	parallax.add_child(artwork)
	add_child(parallax)

func _process(delta: float) -> void:
	_leaf_refresh -= delta
	for leaf in _leaves:
		var pos: Vector2 = leaf["position"]
		pos.y += float(leaf["speed"]) * delta
		pos.x += sin(_leaf_refresh + float(leaf["phase"])) * float(leaf["sway"]) * delta
		if pos.y > 650.0:
			pos.y = randf_range(80.0, 180.0)
			pos.x = randf_range(0.0, world_width)
		leaf["position"] = pos
	if _leaf_refresh <= 0.0:
		_leaf_refresh = 0.15
		queue_redraw()

func _draw() -> void:
	# Low-cost grapple sockets: small permanent rings show valid traversal points.
	for anchor in grapple_anchors:
		draw_circle(anchor, 4.0, Color(0.48, 0.72, 0.78, 0.72))
		draw_arc(anchor, 10.0, 0.0, TAU, 16, Color(0.65, 0.82, 0.86, 0.58), 2.0)
	# Thin translucent fog bands and slow falling leaves are intentionally low-cost on mobile.
	for i in range(4):
		var y := 520.0 + float(i) * 31.0
		draw_rect(Rect2(0, y, world_width, 19), Color(0.54, 0.63, 0.75, 0.025 + float(i) * 0.009))
	for leaf in _leaves:
		var pos: Vector2 = leaf["position"]
		draw_line(pos, pos + Vector2(7, 3), Color(0.74, 0.65, 0.43, 0.48), 2.0)
	draw_rect(Rect2(0, 646, world_width, 4), Color("9c8062"))
