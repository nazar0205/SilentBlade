# SILENT BLADE v0.10.0 — GRAPHICS INTEGRATION

Godot 4.3 · GDScript · 2D stealth-action platformer · Android landscape

Version `0.10.0` · Android version code `11`

**MISSION 01 — THE SHADOW OF THE VILLAGE** remains the first complete mission. v0.9.0 deepens the existing combat, enemy AI, stealth, noise, checkpoint, mission statistics and ranking systems without replacing the v0.8.1 mission or its movement/input architecture.

## v0.9.0 gameplay systems (preserved)

- Katana combo uses explicit `WINDUP → ACTIVE → RECOVERY` phases. Hitbox monitoring is enabled only during ACTIVE, each target can be hit once per swing, buffered taps continue the three-hit chain, and each hit emits a central event.
- Hold-to-block and timed parry remain stamina-based. A successful parry interrupts the enemy attack, causes STAGGER and opens a counter window. Block and guard-break outcomes now have separate visual feedback.
- Player and enemies use state-driven procedural animation poses compatible with the existing custom-drawn characters. No random scale/position animation is used. Attack pose and hitbox phase are driven from the same combo profile/timer.
- The existing EnemyAI FSM remains the only transition authority. Patrols pause/look around at route ends, blocked guards recover, and team alert messages are bounded by area rather than broadcasting the player's live position.
- Noise events carry type, intensity, radius, weight, priority, source and unique ID. Duplicate event IDs are ignored; a global alarm's noise and area broadcast are deduplicated for an enemy that already heard the same siren.
- MissionManager centrally records attacks, landed hits, successful parries, damage, number of hits taken, grapples, distractions, detections, alarms and neutralizations.
- Checkpoint snapshots preserve unique items/objectives/world flags and monotonic run statistics. This is a run-session checkpoint system, not a persistent campaign save slot.
- Ranking uses a fixed 1000-point rubric, displays an explanation, and stores the best result by mission ID in `user://silent_blade_records.cfg`.
- Previous gameplay release metadata was version name `0.9.0`, version code `10`; the current project export metadata is `0.10.0`, code `11`.

## Combat controls

- **Desktop:** `J` / `Z` attack; press during a swing to buffer the next combo link. Hold `K` / `X` to block; the initial 0.18 s is the parry window.
- **Android:** use the existing Katana and hold-to-guard touch buttons. The input layer tracks each finger independently; no new dedicated combat button was added.
- Each combo hit has its own wind-up, active and recovery values, hitbox dimensions, damage and knockback profile. The hitbox remains closed during wind-up and recovery.

## Enemy AI and stealth

The existing FSM states remain `PATROL`, `ALERT`, `INVESTIGATE`, `CHASE`, `ATTACK`, `SEARCH`, `RETURN`, `STAGGER` and `KNOCKBACK`. Guard, Scout and Heavy Guard retain their different vision, hearing, reaction and search profiles. Suspicion is increased by vision/noise through the existing detection system; hearing uses event position only. A heard distraction sends guards to the impact position, not to the player's current position.

## Ranking rubric

Successful missions start at 1000 points. The score is reduced by time after 420 seconds (0.25 points/sec, max 180), detections (90 each, max 360), alarms (65 each, max 260), damage (0.7/HP, max 120), neutralizations (20 each, max 100), missing secrets (35 each) and missing documents (50 each). Optional objectives add 20 each (max 80). Combat execution adds up to 30 points for combo hit accuracy and up to 40 for parries. Score thresholds: **S ≥ 920**, **A ≥ 820**, **B ≥ 680**, **C** for other successful finishes, **D** for failure. These thresholds and deductions are intentionally fixed and tested.

## Run and validate

Open this folder in **Godot 4.3** and run `scenes/Main.tscn` (F6/F5). Headless validation commands:

```bash
godot --headless --path . --editor --quit
godot --headless --path . --quit-after 120
godot --headless --path . -s tests/godot/gameplay_smoke_test.gd
godot --headless --path . -s tests/godot/stealth_ai_test.gd
godot --headless --path . -s tests/godot/mission_systems_test.gd
godot --headless --path . -s tests/godot/v081_grapple_touch_test.gd
godot --headless --path . -s tests/godot/v09_gameplay_systems_test.gd
godot --headless --path . -s tests/godot/v10_background_parallax_test.gd
python -m pytest -q
```

GitHub Actions contains Python source-contract tests, Godot 4.3 import/parser and scene smoke tests, existing gameplay/stealth/mission/grapple tests and the new v0.9 combat/AI/noise/checkpoint/ranking runtime scenario. The Android workflow is configured for a debug arm64 APK at `build/SilentBlade-v0.10.0-debug.apk`.

**Verification limitation for this delivery:** the authoring environment did not have Godot 4.3, Android SDK/ADB, Docker/Podman or a configured Git remote. The Python suite and static configuration checks were run locally. Godot parser/runtime, GitHub Actions execution, Android export and device testing were not performed in this environment. No APK is bundled.

## Known scope limits

- Enemy patrol/search movement is horizontal along placed patrol bounds; cross-platform navigation and autonomous enemy jumping are not implemented.
- Dynamic `Light2D` shadows are not implemented; stealth illumination continues to use low-cost light/dark exposure zones.
- Sound propagation remains radius/intensity based and is not attenuated by walls.
- Checkpoints preserve progress for the active run; campaign-wide persistent save slots are not implemented.
- Combat character animation is procedural state-driven drawing rather than imported sprite sheets. The state/timing interface is extensible for future `AnimationPlayer` or `AnimatedSprite2D` assets.

## Asset provenance

No third-party artwork, music, fonts or commercial assets are included. Level art and VFX use procedural GDScript drawing; existing original synthesized WAV assets remain part of Mission 01.


## v0.10.0 graphics integration — stage 1

- Integrated all 7 Movement animations (42 frames) and 3 selected Mobility animations (19 frames) through a visual-only `AnimatedSprite2D` adapter.
- Preserved Wall Climb and Wall Slide source frames but kept them on the procedural fallback; their source art embeds wall elements.
- Integrated all 5 Bamboo Forest panorama layers using `Parallax2D`.
- Combat Pack was not integrated. Combat, physics, hitboxes, Grappling Hook 2.0, AI, stealth, checkpoints, ranking and Android controls remain on their existing logic.
- Python asset-contract tests and Godot runtime tests are included. Local Godot runtime and Android export are not claimed unless actually executed.

See `docs/V0.10_GRAPHICS_INTEGRATION.md` and `docs/TEST_REPORT_V0.10.md`.
