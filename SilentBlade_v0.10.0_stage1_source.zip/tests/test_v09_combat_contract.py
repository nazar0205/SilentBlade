from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
PLAYER = (ROOT / "scripts/player.gd").read_text(encoding="utf-8")
ENEMY = (ROOT / "scripts/enemy.gd").read_text(encoding="utf-8")
MAIN = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")


def test_three_combo_profiles_have_independent_phase_windows():
    profiles = PLAYER.split("const COMBO_ATTACKS := [", 1)[1].split("const GUARD_MAX", 1)[0]
    assert profiles.count('"name":') == 3
    assert profiles.count('"windup_time":') == 3
    assert profiles.count('"active_time":') == 3
    assert profiles.count('"recovery_time":') == 3


def test_attack_hitbox_is_active_only_in_active_phase():
    assert '"WINDUP"' in PLAYER and '"ACTIVE"' in PLAYER and '"RECOVERY"' in PLAYER
    assert "func _begin_attack_active_phase()" in PLAYER
    assert "func _end_attack_active_phase()" in PLAYER
    assert 'attack_phase = "ACTIVE"' in PLAYER and 'attack_active = true' in PLAYER
    assert "attack_hitbox.set_deferred(\"monitoring\", true)" in PLAYER
    assert "attack_hitbox.set_deferred(\"monitoring\", false)" in PLAYER


def test_combo_input_is_buffered_without_advancing_out_of_order():
    assert "attack_buffer_timer" in PLAYER
    assert "func _buffer_attack_input()" in PLAYER
    assert "func _consume_attack_buffer()" in PLAYER
    assert "COMBO_LINK_WINDOW" in PLAYER


def test_attack_and_hit_events_are_exposed_for_central_statistics():
    for signal_name in ("attack_started", "attack_hit", "damage_received", "grapple_used", "distraction_used"):
        assert re.search(rf"signal\s+{signal_name}\b", PLAYER)
    assert "player.attack_started.connect" in MAIN
    assert "player.attack_hit.connect" in MAIN
    assert "player.damage_received.connect" in MAIN


def test_procedural_animation_states_cover_player_and_enemy():
    for name in ["IDLE", "RUN", "CROUCH", "JUMP", "FALL", "LAND", "DASH", "GRAPPLE", "ATTACK_1", "ATTACK_2", "ATTACK_3", "BLOCK", "PARRY", "HIT", "DEATH"]:
        assert f'"{name}"' in PLAYER
    for name in ["IDLE", "PATROL", "ALERT", "INVESTIGATE", "CHASE", "ATTACK", "HIT", "STAGGER", "KNOCKBACK", "DEATH"]:
        assert f'"{name}"' in ENEMY
    assert "animation_state" in PLAYER and "animation_state" in ENEMY


def test_light_and_heavy_impacts_have_bounded_effect_feedback():
    effect = (ROOT / "scripts/combat/impact_effect.gd").read_text(encoding="utf-8")
    assert "MAX_LIFETIME" in effect
    assert '"PARRY"' in effect and '"HEAVY"' in effect and '"LIGHT"' in effect
    assert "MAX_COMBAT_EFFECTS" in MAIN
    assert "camera_shake_timer" in MAIN


def test_enemy_attack_results_drive_block_and_guard_break_feedback():
    assert "enemy.attack_resolved.connect(_on_enemy_attack_resolved.bind(enemy))" in MAIN
    assert "func _on_enemy_attack_resolved(result: String, enemy: SilentBladeEnemy)" in MAIN
    handler = MAIN.split("func _on_enemy_attack_resolved", 1)[1].split("\nfunc ", 1)[0]
    assert '\t\t"BLOCKED":' in handler
    assert '\t\t"GUARD_BROKEN":' in handler
    assert '_spawn_combat_effect' in handler


def test_player_and_enemy_death_have_visible_state_driven_pose_feedback():
    assert "func _begin_death_animation()" in PLAYER
    assert 'animation_state = "DEATH"' in PLAYER
    assert 'if animation_state == "DEATH":' in PLAYER
    assert 'if animation_state == "DEATH":' in ENEMY
    assert "death_timer" in ENEMY


def test_impact_feedback_draws_bounded_spark_particles_without_particle_nodes():
    effect = (ROOT / "scripts/combat/impact_effect.gd").read_text(encoding="utf-8")
    assert "spark_positions" in effect and "spark_velocities" in effect
    assert "draw_line(spark_positions" in effect
    assert "MAX_LIFETIME" in effect


def test_buffered_combo_is_consumed_if_attack_ended_on_previous_frame():
    assert "func _try_start_buffered_combo() -> void:" in PLAYER
    assert "_try_start_buffered_combo()" in PLAYER.split("func _physics_process", 1)[1].split("func _update_jump_timers", 1)[0]
    method = PLAYER.split("func _try_start_buffered_combo()", 1)[1].split("\nfunc ", 1)[0]
    assert "not attacking" in method and "combo_step <= 0" in method
    assert "attack_cooldown <= 0.0" not in method
    assert "_consume_attack_buffer()" in method
    assert "combo link window" in method
