"""Geometry/physics contracts for the v0.8.1 mission traversal repair."""
from pathlib import Path
import json
import re
import math

ROOT = Path(__file__).resolve().parents[1]
MISSION = json.loads((ROOT / "data/missions/mission_01.json").read_text(encoding="utf-8"))
LEVEL = (ROOT / "scripts/mission/mission_level.gd").read_text(encoding="utf-8")

JUMP_SPEED = 520.0
GRAVITY = 1350.0
MOVE_SPEED = 300.0
DOUBLE_JUMP_SPEED = JUMP_SPEED * 0.94


def _one_jump_range(rise: float) -> float:
    # Positive rise means the target platform is above the launch surface.
    discriminant = JUMP_SPEED * JUMP_SPEED - 2.0 * GRAVITY * rise
    if discriminant < 0:
        return 0.0
    landing_time = (JUMP_SPEED + math.sqrt(discriminant)) / GRAVITY
    return MOVE_SPEED * landing_time


def _two_jump_range(rise: float) -> float:
    first_flight = 2.0 * JUMP_SPEED / GRAVITY
    best_time = 0.0
    # Search the first jump's valid airborne interval for the second-jump press.
    for index in range(1, 2001):
        tau = first_flight * index / 2001.0
        y_at_second_jump = -JUMP_SPEED * tau + 0.5 * GRAVITY * tau * tau
        c = y_at_second_jump + rise
        discriminant = DOUBLE_JUMP_SPEED * DOUBLE_JUMP_SPEED - 2.0 * GRAVITY * c
        if discriminant < 0:
            continue
        total_time = tau + (DOUBLE_JUMP_SPEED + math.sqrt(discriminant)) / GRAVITY
        best_time = max(best_time, total_time)
    return MOVE_SPEED * best_time


def _can_reach(source: dict, target: dict) -> bool:
    source_left = source["x"] - source["width"] / 2
    source_right = source["x"] + source["width"] / 2
    target_left = target["x"] - target["width"] / 2
    target_right = target["x"] + target["width"] / 2
    gap = max(0.0, target_left - source_right, source_left - target_right)
    source_top = source["y"] - source["height"] / 2
    target_top = target["y"] - target["height"] / 2
    rise = source_top - target_top
    if rise <= 100.0:
        budget = _one_jump_range(rise)
    else:
        budget = _two_jump_range(rise)
    # Keep a modest geometric safety margin for acceleration and capsule width.
    return rise <= 185.0 and gap <= budget - 20.0


def test_mission_platforms_are_data_driven_and_built_as_physical_surfaces():
    platforms = MISSION.get("platforms", [])
    assert len(platforms) >= 19
    assert len({p["id"] for p in platforms}) == len(platforms)
    assert "config.get(\"platforms\"" in LEVEL
    assert "_add_platform(" in LEVEL


def test_each_zone_has_a_physical_roof_route_linked_by_jump_or_double_jump():
    platforms = MISSION["platforms"]
    route = [p for p in platforms if p.get("route", False)]
    assert len(route) >= 15
    route.sort(key=lambda p: p["x"])
    # Check the intended adjacent roof route. These are the transitions a player
    # encounters when following the upper path from the outer perimeter to evacuation.
    for source, target in zip(route, route[1:]):
        assert _can_reach(source, target), (
            f"unreachable roof transition {source['id']} -> {target['id']}: "
            f"rise={source['y']-source['height']/2-(target['y']-target['height']/2):.1f}px"
        )


def test_zone_a_has_a_safe_intermediate_step_before_the_first_roof():
    platforms = MISSION["platforms"]
    steps = [p for p in platforms if p.get("id", "").startswith("outer_step")]
    assert len(steps) >= 1
    assert min(p["x"] for p in steps) < 300
    assert max(p["y"] - p["height"] / 2 for p in steps) < 620


def test_house_facades_have_player_and_raycast_blocking_collision():
    house_block = re.search(r"func _add_house\(.*?(?=\nfunc )", LEVEL, re.S).group(0)
    assert "StaticBody2D.new()" in house_block
    assert "CollisionShape2D.new()" in house_block
    assert "collision_layer = 1" in house_block


def test_archive_has_a_real_doorway_between_two_opaque_wall_sections():
    archive_block = re.search(r"func _add_archive_facade\(.*?(?=\nfunc )", LEVEL, re.S).group(0)
    assert "for local_x in [-112.0, 112.0]" in archive_block
    assert "StaticBody2D.new()" in archive_block
    assert "wall_rect.size = Vector2(66.0, 220.0)" in archive_block
    assert re.search(r'"archive_side_door".*Vector2\(4210(?:\.0)?,\s*650', LEVEL)
