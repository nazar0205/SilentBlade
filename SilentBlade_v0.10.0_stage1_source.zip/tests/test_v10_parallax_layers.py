from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parents[1]
LEVEL = (ROOT / "scripts/mission/mission_level.gd").read_text(encoding="utf-8")
ASSET_ROOT = ROOT / "assets/backgrounds/bamboo_forest/parallax"

LAYERS = [
    ("Sky", "01_sky_moon_clouds.png", 0.08, -50, -64.0),
    ("Mountains", "02_distant_mountains.png", 0.18, -40, 43.0),
    ("Forest", "03_forest_cliffs_waterfalls.png", 0.32, -30, -250.0),
    ("Architecture", "04_japanese_architecture.png", 0.36, -20, -280.0),
    ("Foreground", "05_foreground_bamboo_rocks_grass.png", 0.38, -10, -645.0),
]


def test_parallax_builder_creates_five_layers_in_depth_order():
    assert LEVEL.count("Parallax2D.new()") == 1
    assert LEVEL.count("_add_bamboo_parallax_layer(") == 6  # five calls + helper definition
    positions = [LEVEL.index(item[1]) for item in LAYERS]
    assert positions == sorted(positions)


def test_each_layer_uses_its_art_scroll_scale_and_depth():
    for name, filename, scroll, depth, y_offset in LAYERS:
        assert filename in LEVEL, filename
        assert f'"{name}"' in LEVEL
        assert f"Vector2({scroll:.2f}, 0.0)" in LEVEL
        assert f", 1.0, {depth}, {y_offset:.1f}" in LEVEL


def test_background_assets_have_expected_dimensions_and_alpha():
    for index, (_name, filename, *_rest) in enumerate(LAYERS):
        path = ASSET_ROOT / filename
        assert path.is_file(), filename
        data = path.read_bytes()
        assert data[:8] == b"\x89PNG\r\n\x1a\n"
        width, height, bit_depth, color_type = struct.unpack(">IIBB", data[16:26])
        assert width == 4096
        assert height >= 677
        assert bit_depth == 8
        assert color_type in {2, 6}
        if index > 0:
            assert color_type == 6  # RGBA transparency is part of these layered images.


def test_scroll_factors_cover_expanded_mobile_view_without_texture_tiling():
    # 19.5:9 at a 720 px viewport height is 1560 logical pixels wide;
    # 1600 px is retained as a small safety margin.
    maximum_view_width = 1600.0
    world_width = 6200.0
    for _name, filename, scroll, *_rest in LAYERS:
        required = maximum_view_width + world_width * scroll
        data = (ASSET_ROOT / filename).read_bytes()
        width = struct.unpack(">I", data[16:20])[0]
        assert width >= required
    # The supplied panoramas are not seamless at their edges, so they are not tiled.
    helper = LEVEL.split("func _add_bamboo_parallax_layer", 1)[1].split("func _process", 1)[0]
    assert "repeat_size = Vector2.ZERO" in helper
    assert "repeat_times = 1" in helper


def test_background_layers_have_no_physics_geometry_and_keep_uniform_scale():
    builder = LEVEL.split("func _build_parallax", 1)[1].split("func _add_bamboo_parallax_layer", 1)[0]
    helper = LEVEL.split("func _add_bamboo_parallax_layer", 1)[1].split("func _process", 1)[0]
    for text in (builder, helper):
        assert "StaticBody2D" not in text
        assert "CollisionShape2D" not in text
    assert "Vector2(scale_value, scale_value)" in helper
    assert "Vector2(scale_x, scale_y)" not in helper
    assert "ParallaxBackground.new()" not in builder
    assert "ParallaxLayer.new()" not in builder


def test_player_visual_adapter_uses_sprite_frames_and_keeps_procedural_fallback():
    player = (ROOT / "scripts/player.gd").read_text(encoding="utf-8")
    assert "func _draw()" in player
    assert "AnimatedSprite2D.new()" in player
    assert "_draw_visual_overlays()" in player
    assert "animation_sprite.visible = false" in player
    assert (ROOT / "assets/characters/player/player_movement_frames.tres").is_file()


def test_project_targets_godot_4_3_and_version_0_10():
    project = (ROOT / "project.godot").read_text(encoding="utf-8")
    assert 'config/features=PackedStringArray("4.3", "GL Compatibility")' in project
    assert 'config/version="0.10.0"' in project
