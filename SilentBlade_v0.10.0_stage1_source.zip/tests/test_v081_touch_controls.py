"""Touch layout/settings contracts with geometric hit-area checks."""
from pathlib import Path
import re
import math

ROOT = Path(__file__).resolve().parents[1]
TOUCH = (ROOT / "scripts/input/touch_controls.gd").read_text(encoding="utf-8")
MAIN = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")


def _button_defs():
    pattern = re.compile(
        r'\{"action": "([^"]+)", "label": "[^"]*", "glyph": "[^"]*", '
        r'"offset": Vector2\(([\d.]+), ([\d.]+)\), "radius": ([\d.]+)'
    )
    items = []
    for action, ox, oy, radius in pattern.findall(TOUCH):
        items.append((action, float(ox), float(oy), float(radius)))
    return items


def _hit_rects(view_w: float, view_h: float, button_scale: float = 0.92):
    scale = min(view_w / 1280.0, view_h / 720.0)
    scale = max(0.7, min(1.6, scale)) * button_scale
    items = _button_defs()
    rects = []
    for action, ox, oy, radius in items:
        cx, cy = view_w - ox * scale, view_h - oy * scale
        reach = radius * scale + 10.0 * scale
        rects.append((action, cx, cy, reach))
    return rects


def test_all_mobile_actions_keep_independent_controls():
    actions = {item[0] for item in _button_defs()}
    assert actions == {"attack", "jump", "dash", "grapple", "block", "crouch", "distract", "interact"}


def test_padded_hit_areas_do_not_overlap_at_16_9_and_19_5_9_landscape():
    for width, height in ((1280.0, 720.0), (1560.0, 720.0), (2400.0, 1080.0), (854.0, 480.0)):
        for button_scale in (0.78, 0.92, 1.12):
            rects = _hit_rects(width, height, button_scale)
            assert len(rects) == 8
            for i, first in enumerate(rects):
                for second in rects[i + 1:]:
                    distance = math.hypot(first[1] - second[1], first[2] - second[2])
                    assert distance > first[3] + second[3], (
                        f"overlap on {width}x{height} size={button_scale}: {first[0]} vs {second[0]}"
                    )
            # The right-side buttons must not intrude into the left joystick's touch zone.
            stick_zone_right = width * 0.46
            for button in rects:
                assert button[1] - button[3] > stick_zone_right, (
                    f"button {button[0]} overlaps joystick zone on {width}x{height} size={button_scale}"
                )
                assert button[1] - button[3] >= 0.0
                assert button[1] + button[3] <= width
                assert button[2] - button[3] >= 0.0
                assert button[2] + button[3] <= height


def test_touch_controls_expose_safe_size_and_opacity_preferences():
    assert "@export var button_scale" in TOUCH
    assert "@export var button_opacity" in TOUCH
    assert "debug_overlay = false" in MAIN
    assert "user://silent_blade_controls.cfg" in MAIN
    assert "_load_touch_control_preferences()" in MAIN
    assert "_save_touch_control_preferences()" in MAIN


def test_pause_menu_contains_live_control_settings():
    pause = re.search(r"func _build_pause_panel\(.*?(?=\nfunc )", MAIN, re.S).group(0)
    assert "HSlider.new()" in pause
    assert "button_scale" in pause
    assert "button_opacity" in pause
    assert "_on_touch_size_changed" in pause
    assert "_on_touch_opacity_changed" in pause


def test_viewport_layout_is_recomputed_on_resize_and_uses_safe_scale():
    assert "NOTIFICATION_RESIZED" in TOUCH
    assert "func _relayout()" in TOUCH
    assert "button_scale" in TOUCH


def test_main_uses_the_registered_touch_controls_type_for_custom_settings():
    assert "var touch_controls: SilentBladeTouchControls" in MAIN
    assert "class_name SilentBladeTouchControls" in TOUCH
    assert "touch_controls.button_scale" in MAIN
    assert "touch_controls.button_opacity" in MAIN


def test_android_export_metadata_matches_current_v10_release():
    export = (ROOT / "export_presets.cfg").read_text(encoding="utf-8")
    workflow = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")
    assert 'version/code=11' in export
    assert 'version/name="0.10.0"' in export
    assert 'APK_PATH: build/SilentBlade-v0.10.0-debug.apk' in workflow
    assert 'export_path="build/SilentBlade-v0.10.0-debug.apk"' in export
    assert 'name: SilentBlade-v0.10.0-arm64-v8a-debug-apk' in workflow


def test_godot_runtime_test_is_wired_into_the_existing_validation_workflow():
    workflow = (ROOT / ".github/workflows/godot-validation.yml").read_text(encoding="utf-8")
    test_script = ROOT / "tests/godot/v081_grapple_touch_test.gd"
    assert test_script.is_file()
    assert "godot --headless --path . -s tests/godot/v081_grapple_touch_test.gd" in workflow
    assert "godot-v081.log" in workflow
