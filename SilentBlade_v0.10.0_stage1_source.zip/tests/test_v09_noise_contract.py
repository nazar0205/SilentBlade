from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NOISE = (ROOT / "scripts/stealth/noise_system.gd").read_text(encoding="utf-8")
ENEMY = (ROOT / "scripts/enemy.gd").read_text(encoding="utf-8")
DECOY = (ROOT / "scripts/stealth/noise_decoy.gd").read_text(encoding="utf-8")


def test_noise_types_have_different_weighted_profiles():
    for event in ["SNEAK_STEP", "FOOTSTEP", "JUMP", "LAND", "FALL", "DASH", "GRAPPLE", "ATTACK", "DECOY", "INTERACTION"]:
        assert f'"{event}"' in NOISE
    assert "event_weight" in NOISE and "priority" in NOISE


def test_enemy_deduplicates_noise_event_ids_and_uses_event_weight():
    assert "heard_noise_ids" in ENEMY
    assert "event_weight" in ENEMY
    assert "hearing_sensitivity" in ENEMY


def test_decoy_emits_one_noise_at_physical_collision_position():
    assert "move_and_slide()" in DECOY
    assert "if is_on_floor() or get_slide_collision_count() > 0" in DECOY
    assert "global_position, 480.0" in DECOY
    assert "if emitted" in DECOY


def test_noise_priority_affects_audibility_strength():
    assert 'var event_priority := int(event.get("priority", 1))' in ENEMY
    assert "event_priority" in ENEMY
    assert "priority_factor" in ENEMY
