from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MISSION = (ROOT / "scripts/mission/mission_manager.gd").read_text(encoding="utf-8")
CHECKPOINT = (ROOT / "scripts/mission/checkpoint_system.gd").read_text(encoding="utf-8")
MAIN = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")


def test_mission_manager_tracks_all_requested_combat_and_stealth_stats():
    for field in ["attacks", "hits_landed", "parries", "damage_taken", "grapple_uses", "distractions_used"]:
        assert field in MISSION
    assert "func record_event(event_name: String, amount: float = 1.0) -> void" in MISSION


def test_main_routes_player_and_enemy_events_to_one_mission_manager():
    for call in ["record_event(\"attacks\"", "record_event(\"hits_landed\"", "record_event(\"parries\"", "record_event(\"damage_taken\"", "record_event(\"grapple_uses\"", "record_event(\"distractions_used\""]:
        assert call in MAIN


def test_checkpoint_snapshot_is_versioned_and_contains_mission_progress():
    assert "SNAPSHOT_VERSION" in CHECKPOINT
    assert '"mission_state"' in CHECKPOINT
    assert '"version"' in CHECKPOINT
    assert "snapshot_persistent_state()" in MAIN
    assert "restore_progress_state" in MAIN


def test_mission_statistics_track_number_of_player_hits_separately_from_damage_amount():
    assert "var hits_taken := 0" in MISSION
    assert '"hits_taken": hits_taken' in MISSION
    assert '"hits_taken": hits_taken' in MISSION
    assert 'hits_taken = int(saved_stats.get("hits_taken"' in MISSION
    assert 'hits_taken = maxi(hits_taken, int(saved_stats.get("hits_taken"' in MISSION
    assert 'record_event("hits_taken")' in MAIN
    assert '"hits_taken"' in MAIN


def test_main_does_not_keep_duplicate_detection_or_neutralization_counters():
    assert "var detections := 0" not in MAIN
    assert "var defeated_enemies := 0" not in MAIN
    assert "detections += 1" not in MAIN
    assert "defeated_enemies += 1" not in MAIN
