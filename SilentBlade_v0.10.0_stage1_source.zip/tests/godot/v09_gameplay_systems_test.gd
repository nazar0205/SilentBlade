extends SceneTree
## v0.9 runtime checks for the existing combat, AI, noise, progress and ranking modules.
## Run with: godot --headless --path . -s tests/godot/v09_gameplay_systems_test.gd

const PlayerScript = preload("res://scripts/player.gd")
const EnemyScript = preload("res://scripts/enemy.gd")
const NoiseScript = preload("res://scripts/stealth/noise_system.gd")
const MissionManagerScript = preload("res://scripts/mission/mission_manager.gd")
const MissionResultsScript = preload("res://scripts/mission/mission_results.gd")
const CheckpointScript = preload("res://scripts/mission/checkpoint_system.gd")
const EnemyAIScript = preload("res://scripts/ai/enemy_ai.gd")

var _failures := 0

func _initialize() -> void:
	call_deferred("_run")

func _check(condition: bool, label: String) -> void:
	if condition:
		print("PASS: ", label)
	else:
		print("FAIL: ", label)
		_failures += 1

func _run() -> void:
	# A real Player node drives the same wind-up/active/recovery functions as gameplay.
	var player: SilentBladePlayer = PlayerScript.new()
	root.add_child(player)
	player.set_physics_process(false)
	player.global_position = Vector2(200.0, 300.0)
	player.start_attack()
	_check(player.attack_phase == "WINDUP" and not player.attack_active, "katana strike begins in wind-up with hitbox inactive")
	player._update_attack_sequence(0.06)
	_check(player.attack_phase == "ACTIVE" and player.attack_active, "katana hitbox opens only during the active window")
	await process_frame
	_check(player.attack_hitbox.monitoring, "active hitbox is enabled in the physics server")

	var enemy: SilentBladeEnemy = EnemyScript.new()
	enemy.enemy_type = "Guard"
	enemy.target = player
	root.add_child(enemy)
	enemy.set_physics_process(false)
	enemy.global_position = player.global_position + Vector2(58.0, 0.0)
	var health_before := enemy.health
	player._register_attack_target(enemy)
	var health_after_first_hit := enemy.health
	player._register_attack_target(enemy)
	_check(is_equal_approx(health_after_first_hit, health_before - 22.0), "first combo strike applies authored damage")
	_check(is_equal_approx(enemy.health, health_after_first_hit), "same enemy cannot be hit twice by one swing")
	_check(enemy.state == "STAGGER", "light sword hit produces stagger reaction")

	player._update_attack_sequence(0.12)
	await process_frame
	_check(player.attack_phase == "RECOVERY" and not player.attack_active and not player.attack_hitbox.monitoring, "hitbox closes before recovery")
	player._update_attack_sequence(0.20)
	_check(not player.attacking and player.attack_phase == "IDLE", "strike exits recovery and returns to idle")

	# Buffering during a swing starts the next authored strike without skipping its profile.
	player.start_attack()
	player._buffer_attack_input()
	player._update_attack_sequence(0.50)
	_check(player.current_attack_index == 1 and player.attacking, "buffered combo input advances to strike two")
	_check(player.attack_phase in ["ACTIVE", "RECOVERY"], "buffered second strike follows its own phase timing")
	player._end_attack()
	# A tap on the frame immediately after a swing ended must still start the next link.
	player.combo_step = 1
	player.combo_timer = 0.5
	player.attack_cooldown = 0.18
	player.attack_buffer_timer = 0.20
	player._try_start_buffered_combo()
	_check(player.attacking and player.current_attack_index == 1, "late buffered tap starts next combo link while link window is alive")
	player._end_attack()

	# Enemy profile resistance distinguishes stagger from heavy knockback.
	var heavy: SilentBladeEnemy = EnemyScript.new()
	heavy.enemy_type = "Heavy Guard"
	heavy.target = player
	root.add_child(heavy)
	heavy.set_physics_process(false)
	heavy.global_position = player.global_position + Vector2(100.0, 0.0)
	heavy.receive_damage(40.0, player.global_position, 500.0)
	_check(heavy.state == "KNOCKBACK", "heavy strike pushes a Heavy Guard into knockback")

	# Parry must interrupt the enemy's existing attack and create a counter window.
	heavy.state = "ATTACK"
	heavy.attack_phase = "TELEGRAPH"
	player.facing = 1
	player.begin_block()
	_check(player.try_parry(heavy), "timed guard input successfully parries an incoming attack")
	_check(heavy.state == "STAGGER" and player.counter_window_timer > 0.0, "parry interrupts the attacker and opens a counter window")
	player.end_block()

	# The existing AI FSM remains the single state-transition authority.
	var ai = EnemyAIScript.new()
	_check(ai.can_transition("PATROL", "ALERT") and ai.can_transition("CHASE", "SEARCH"), "existing enemy FSM permits core stealth transitions")

	# Noise is delivered through NoiseSystem; the listener investigates the event point, not the player's live transform.
	var noise: SilentBladeNoiseSystem = NoiseScript.new()
	root.add_child(noise)
	var listener: SilentBladeEnemy = EnemyScript.new()
	listener.enemy_type = "Scout"
	listener.target = player
	listener.noise_system = noise
	listener.global_position = Vector2(620.0, 300.0)
	root.add_child(listener)
	listener.set_physics_process(false)
	var event_position := Vector2(650.0, 300.0)
	noise.emit_noise(event_position, 360.0, 0.82, "DECOY", 1234)
	_check(listener.state == "ALERT", "enemy hearing a decoy enters alert")
	_check(listener.investigate_position == event_position, "enemy investigates the sound origin")
	_check(listener.last_known_player_position != player.global_position and not listener.has_last_known_position, "sound does not reveal live player position")
	var suspicion_after_first_event := listener.detection_meter
	var first_noise_event: Dictionary = noise.active_events[0]
	listener.on_noise_event(first_noise_event)
	_check(is_equal_approx(listener.detection_meter, suspicion_after_first_event), "duplicate noise event ID is ignored")
	var alarm_position := Vector2(660.0, 300.0)
	noise.emit_noise(alarm_position, 1720.0, 1.0, "GLOBAL_ALARM", -1)
	var suspicion_after_alarm := listener.detection_meter
	_check(listener.receive_team_alert(alarm_position, 1720.0, "GLOBAL"), "bounded global team alarm reaches the listener")
	_check(is_equal_approx(listener.detection_meter, suspicion_after_alarm), "alarm noise plus its team broadcast does not double-count suspicion")

	# Centralized mission counters survive checkpoint restoration without duplicate or rewind.
	var config_value = JSON.parse_string(FileAccess.get_file_as_string("res://data/missions/mission_01.json"))
	_check(config_value is Dictionary, "Mission 01 config remains valid")
	if config_value is Dictionary:
		var manager: SilentBladeMissionManager = MissionManagerScript.new()
		root.add_child(manager)
		manager.start_mission(config_value)
		manager.record_event("attacks")
		manager.record_event("hits_landed")
		manager.record_event("hits_taken")
		manager.record_event("parries")
		manager.record_event("damage_taken", 17.5)
		manager.record_event("grapple_uses")
		manager.record_event("distractions_used")
		var checkpoint: SilentBladeCheckpointSystem = CheckpointScript.new()
		root.add_child(checkpoint)
		_check(checkpoint.activate("v09_runtime", Vector2(1200.0, 500.0), false, manager.snapshot_persistent_state()), "checkpoint accepts a versioned mission snapshot")
		manager.record_event("hits_taken")
		manager.record_event("damage_taken", 4.0)
		var saved_mission_state: Dictionary = checkpoint.get_snapshot().get("mission_state", {})
		manager.restore_progress_state(saved_mission_state)
		var stats: Dictionary = manager.get_stats()
		_check(int(stats.get("hits_taken", 0)) == 2, "hit count is retained and never rewound by checkpoint")
		_check(is_equal_approx(float(stats.get("damage_taken", 0.0)), 21.5), "damage total remains monotonic after checkpoint restore")
		_check(int(stats.get("parries", 0)) == 1 and int(stats.get("hits_landed", 0)) == 1, "combat counters are included in mission snapshot")

	# Fixed ranking rubric returns reproducible scores, explanations and persistent best records.
	var perfect := {
		"success": true, "elapsed_time": 400.0, "detections": 0, "alarms": 0,
		"damage_taken": 0.0, "neutralized": 0, "secrets_found": 2, "secrets_total": 2,
		"documents_collected": 2, "documents_total": 2, "attacks": 5, "hits_landed": 5,
		"parries": 2, "hits_taken": 0
	}
	_check(MissionResultsScript.score(perfect) == 1000 and MissionResultsScript.evaluate(perfect) == "S", "perfect stealth and combat run earns S and 1000 points")
	var explanation: Array[String] = MissionResultsScript.explain(perfect)
	var has_accuracy_reason := false
	var has_parry_reason := false
	for explanation_line in explanation:
		if explanation_line.contains("Комбо-точность"):
			has_accuracy_reason = true
		if explanation_line.contains("Парирования"):
			has_parry_reason = true
	_check(has_accuracy_reason and has_parry_reason, "ranking explains combo accuracy and parry bonuses")

	var test_mission_id := "__v09_gameplay_runtime_test"
	var cleanup := ConfigFile.new()
	if cleanup.load(MissionResultsScript.BEST_RESULTS_PATH) == OK:
		cleanup.erase_section_key("best", test_mission_id)
		cleanup.save(MissionResultsScript.BEST_RESULTS_PATH)
	var best_result := {"success": true, "rank": "A", "score": 900, "elapsed_time": 520.0}
	var lower_result := {"success": true, "rank": "B", "score": 820, "elapsed_time": 600.0}
	_check(MissionResultsScript.save_best(test_mission_id, best_result), "first valid run is saved as best result")
	_check(not MissionResultsScript.save_best(test_mission_id, lower_result), "lower score cannot overwrite the best result")
	_check(int(MissionResultsScript.load_best(test_mission_id).get("score", 0)) == 900, "best result persists by mission ID")
	if cleanup.load(MissionResultsScript.BEST_RESULTS_PATH) == OK:
		cleanup.erase_section_key("best", test_mission_id)
		cleanup.save(MissionResultsScript.BEST_RESULTS_PATH)

	print("RESULT: ", "FAILED (%d)" % _failures if _failures > 0 else "ALL PASSED")
	quit(1 if _failures > 0 else 0)
