extends SceneTree

const PlayerScript = preload("res://scripts/player.gd")
const TouchControlsScript = preload("res://scripts/input/touch_controls.gd")

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	for action in ["jump", "grapple"]:
		if not InputMap.has_action(action):
			InputMap.add_action(action)

	# Real touch control node: two fingers must own independent buttons.
	var touch = TouchControlsScript.new()
	touch.name = "V081TouchControlsTest"
	root.add_child(touch)
	await process_frame
	touch.set_enabled(true)
	var jump_center: Vector2 = touch.get_button_center("jump")
	var grapple_center: Vector2 = touch.get_button_center("grapple")
	assert(jump_center != Vector2.INF, "jump control is laid out")
	assert(grapple_center != Vector2.INF, "grapple control is laid out")
	touch._begin_touch(1, jump_center)
	touch._begin_touch(2, grapple_center)
	assert(touch.is_action_held("jump"), "first finger holds jump")
	assert(touch.is_action_held("grapple"), "second finger holds grapple")
	touch._end_touch(1)
	assert(not touch.is_action_held("jump"), "released finger releases only its action")
	assert(touch.is_action_held("grapple"), "other finger still holds grapple")
	touch.release_all()
	touch.queue_free()

	# Real player node: attaching never snaps the body, reel shortens the rope,
	# detaching preserves the current velocity.
	var player: SilentBladePlayer = PlayerScript.new()
	player.position = Vector2(100.0, 400.0)
	player.anchors.append(Vector2(360.0, 300.0))
	root.add_child(player)
	await physics_frame
	var original_position := player.global_position
	player._attach_grapple()
	assert(player.grappling, "clear anchor attaches")
	assert(player.global_position.is_equal_approx(original_position), "attachment does not teleport player")
	var original_length := player.rope_length
	player._apply_grapple_control(1.0, 0.0, true)
	assert(player.rope_length < original_length, "held grapple reels in rope")
	assert(player.rope_length >= player.GRAPPLE_MIN_ROPE_LENGTH, "rope respects minimum length")
	player.velocity = Vector2(170.0, -95.0)
	var release_velocity := player.velocity
	player._detach_grapple()
	assert(not player.grappling, "detach clears grapple state")
	assert(player.velocity.is_equal_approx(release_velocity), "detach preserves velocity")
	assert(player.global_position.is_equal_approx(original_position), "detach does not snap position")

	# Opaque collision must block the physical grapple ray.
	var wall := StaticBody2D.new()
	wall.collision_layer = 1
	wall.collision_mask = 1
	wall.position = Vector2(230.0, 340.0)
	var wall_shape := CollisionShape2D.new()
	var wall_rect := RectangleShape2D.new()
	wall_rect.size = Vector2(40.0, 160.0)
	wall_shape.shape = wall_rect
	wall.add_child(wall_shape)
	root.add_child(wall)
	await physics_frame
	assert(not player._has_clear_grapple_line(Vector2(360.0, 300.0)), "wall blocks grapple line")
	player.queue_free()
	wall.queue_free()
	print("RESULT: ALL PASSED")
	quit(0)
