extends SceneTree
## Runtime integration test for the five user-supplied Bamboo Forest background layers.
## Run: godot --headless --path . -s tests/godot/v10_background_parallax_test.gd

const MissionLevelScript = preload("res://scripts/mission/mission_level.gd")
const StealthSystemScript = preload("res://scripts/stealth/stealth_system.gd")

var _failures := 0
var _checks := 0

func _initialize() -> void:
	call_deferred("_run")

func _check(condition: bool, label: String) -> void:
	_checks += 1
	if condition:
		print("PASS: ", label)
	else:
		_failures += 1
		push_error("FAIL: " + label)

func _run() -> void:
	var stealth: SilentBladeStealthSystem = StealthSystemScript.new()
	root.add_child(stealth)
	var level: SilentBladeMissionLevel = MissionLevelScript.new()
	root.add_child(level)
	level.build(stealth)
	await process_frame

	var expected := [
		{"name": "Sky", "file": "01_sky_moon_clouds.png", "scroll": 0.08, "z": -50},
		{"name": "Mountains", "file": "02_distant_mountains.png", "scroll": 0.18, "z": -40},
		{"name": "Forest", "file": "03_forest_cliffs_waterfalls.png", "scroll": 0.32, "z": -30},
		{"name": "Architecture", "file": "04_japanese_architecture.png", "scroll": 0.36, "z": -20},
		{"name": "Foreground", "file": "05_foreground_bamboo_rocks_grass.png", "scroll": 0.38, "z": -10}
	]
	for item in expected:
		var layer_name := "Bamboo%sParallax" % item["name"]
		var parallax := level.get_node_or_null(layer_name) as Parallax2D
		_check(parallax != null, "%s Parallax2D exists" % item["name"])
		if parallax == null:
			continue
		_check(is_equal_approx(parallax.scroll_scale.x, float(item["scroll"])), "%s scroll scale loads" % item["name"])
		_check(parallax.z_index == int(item["z"]), "%s depth order is configured" % item["name"])
		_check(parallax.repeat_size == Vector2.ZERO and parallax.repeat_times == 1, "%s panorama is not tiled" % item["name"])
		_check(parallax.get_child_count() == 1 and parallax.get_child(0) is Sprite2D, "%s contains one visual sprite only" % item["name"])
		if parallax.get_child_count() == 1 and parallax.get_child(0) is Sprite2D:
			var artwork := parallax.get_child(0) as Sprite2D
			_check(artwork.texture != null, "%s texture resource loads" % item["name"])
			if artwork.texture != null:
				_check(artwork.texture.get_width() == 4096, "%s keeps the source width" % item["name"])
		_check(parallax.find_children("*", "CollisionObject2D", true, false).is_empty(), "%s has no collision geometry" % item["name"])

	_check(level.world_width >= 6200.0, "existing mission world width is preserved")
	_check(level.enemy_spawns.size() >= 8, "existing enemy spawns are preserved")
	_check(level.interactables.size() >= 10, "existing mission interactables are preserved")
	print("RESULT: %d checks, %d failures" % [_checks, _failures])
	quit(1 if _failures > 0 else 0)
