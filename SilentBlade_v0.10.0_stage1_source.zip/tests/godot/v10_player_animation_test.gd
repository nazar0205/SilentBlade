extends SceneTree
## Runtime integration test for the selected movement and mobility SpriteFrames.
## Run: godot --headless --path . -s tests/godot/v10_player_animation_test.gd

const PlayerScript = preload("res://scripts/player.gd")

var _checks := 0
var _failures := 0

func _initialize() -> void:
	call_deferred("_run")

func _check(condition: bool, label: String) -> void:
	_checks += 1
	if condition:
		print("PASS: ", label)
	else:
		_failures += 1
		push_error("FAIL: " + label)

func _run() -> void:
	var player: SilentBladePlayer = PlayerScript.new()
	root.add_child(player)
	await process_frame
	var sprite := player.get_node_or_null("PlayerAnimatedSprite") as AnimatedSprite2D
	_check(sprite != null, "player owns one AnimatedSprite2D child")
	if sprite == null:
		quit(1)
		return
	var expected := {
		"idle": 8, "walk": 8, "run": 8, "crouch": 4,
		"jump": 6, "fall": 4, "land": 4,
		"dash": 6, "grapple_shoot": 5, "grapple_swing": 8
	}
	for animation_name in expected:
		_check(sprite.sprite_frames.has_animation(animation_name), "%s animation exists" % animation_name)
		if sprite.sprite_frames.has_animation(animation_name):
			_check(sprite.sprite_frames.get_frame_count(animation_name) == int(expected[animation_name]), "%s frame count matches source pack" % animation_name)
	_check(not sprite.sprite_frames.has_animation("wall_climb"), "wall climb uses procedural fallback")
	_check(not sprite.sprite_frames.has_animation("wall_slide"), "wall slide uses procedural fallback")

	player.animation_state = "RUN"
	player.facing = -1
	player.call("_sync_animation_sprite", true)
	_check(sprite.visible and sprite.animation == &"run", "run state selects run animation")
	_check(sprite.flip_h, "left-facing direction flips sprite")

	player.animation_state = "ATTACK_1"
	player.call("_sync_animation_sprite", true)
	_check(not sprite.visible, "unsupported combat state uses procedural fallback")

	player.animation_state = "DASH"
	player.call("_sync_animation_sprite", true)
	_check(sprite.visible and sprite.animation == &"dash", "dash selects mobility animation")
	_check(is_equal_approx(sprite.speed_scale, 2.5), "dash animation is accelerated to fit the existing dash window")

	player.grappling = true
	player.grapple_shoot_visual_timer = 0.25
	player.call("_update_animation_state", 0.016)
	_check(sprite.visible and sprite.animation == &"grapple_shoot", "grapple attach starts one-shot shoot animation")
	player.grapple_shoot_visual_timer = 0.0
	player.call("_update_animation_state", 0.016)
	_check(sprite.visible and sprite.animation == &"grapple_swing", "grapple shoot transitions to swing")

	player.animation_state = "BLOCK"
	player.call("_sync_animation_sprite", true)
	_check(not sprite.visible, "block remains on existing procedural fallback")
	_check(player.get_node_or_null("AttackHitbox") is Area2D, "existing attack hitbox remains attached")
	_check(player.get_node_or_null("CollisionShape2D") is CollisionShape2D, "existing player collision remains attached")

	print("RESULT: %d checks, %d failures" % [_checks, _failures])
	player.queue_free()
	quit(1 if _failures > 0 else 0)
