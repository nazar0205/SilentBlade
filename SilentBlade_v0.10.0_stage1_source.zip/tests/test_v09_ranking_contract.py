from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULTS = (ROOT / "scripts/mission/mission_results.gd").read_text(encoding="utf-8")
MANAGER = (ROOT / "scripts/mission/mission_manager.gd").read_text(encoding="utf-8")
MAIN = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")


def test_ranking_has_fixed_score_and_transparent_reason_methods():
    assert "static func score(stats: Dictionary) -> int" in RESULTS
    assert "static func evaluate(stats: Dictionary) -> String" in RESULTS
    assert "static func explain(stats: Dictionary) -> Array[String]" in RESULTS
    for threshold in ["S_SCORE_THRESHOLD", "A_SCORE_THRESHOLD", "B_SCORE_THRESHOLD"]:
        assert threshold in RESULTS


def test_best_result_is_persisted_by_mission_id_and_never_downgraded():
    assert "static func load_best(mission_id: String) -> Dictionary" in RESULTS
    assert "static func save_best(mission_id: String, result: Dictionary) -> bool" in RESULTS
    assert "user://silent_blade_records.cfg" in RESULTS
    assert "save_best(" in MANAGER


def test_results_screen_shows_score_reasons_and_previous_best():
    assert '"score"' in MANAGER
    assert '"score_reasons"' in MANAGER
    assert '"previous_best"' in MANAGER
    assert "ЛУЧШИЙ РЕЗУЛЬТАТ" in MAIN
    assert "ОЦЕНКА" in MAIN


def test_ranking_rewards_combat_execution_and_explains_the_bonus():
    assert "parry_bonus" in RESULTS
    assert "accuracy_bonus" in RESULTS
    assert "Комбо-точность" in RESULTS
    assert "Парирования" in RESULTS


def test_ranking_counts_optional_objectives_without_gdscript_lambda_filter():
    assert "static func _count_completed_optional(stats: Dictionary) -> int" in RESULTS
    assert ".filter(func(" not in RESULTS


def test_v09_runtime_test_and_android_release_metadata_are_wired():
    runtime_test = ROOT / "tests/godot/v09_gameplay_systems_test.gd"
    assert runtime_test.is_file()
    validation = (ROOT / ".github/workflows/godot-validation.yml").read_text(encoding="utf-8")
    assert "tests/godot/v09_gameplay_systems_test.gd" in validation
    preset = (ROOT / "export_presets.cfg").read_text(encoding="utf-8")
    assert 'version/code=11' in preset
    assert 'version/name="0.10.0"' in preset
    assert 'export_path="build/SilentBlade-v0.10.0-debug.apk"' in preset
    android_workflow = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")
    assert "APK_PATH: build/SilentBlade-v0.10.0-debug.apk" in android_workflow
    assert "SilentBlade-v0.10.0-arm64-v8a-debug-apk" in android_workflow
