from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
PLAYER = (ROOT / "scripts/player.gd").read_text(encoding="utf-8")

MOVEMENT_ANIMS = {"idle", "walk", "run", "crouch", "jump", "fall", "land"}
MOBILITY_ANIMS = {"dash", "grapple_shoot", "grapple_swing"}


def _resource_animations(path: Path) -> set[str]:
    text = path.read_text(encoding="utf-8")
    return set(re.findall(r'"name": &"([^"]+)"', text))


def test_movement_spriteframes_contains_all_seven_animations_and_valid_paths():
    path = ROOT / "assets/characters/player/player_movement_frames.tres"
    assert path.is_file()
    source = path.read_text(encoding="utf-8")
    assert MOVEMENT_ANIMS <= _resource_animations(path)
    for resource_path in re.findall(r'path="res://([^"]+\.png)"', source):
        assert (ROOT / resource_path).is_file(), resource_path


def test_mobility_spriteframes_contains_three_supported_animations_and_valid_paths():
    path = ROOT / "assets/characters/player/player_mobility_frames.tres"
    assert path.is_file()
    source = path.read_text(encoding="utf-8")
    assert MOBILITY_ANIMS <= _resource_animations(path)
    for resource_path in re.findall(r'path="res://([^"]+\.png)"', source):
        assert (ROOT / resource_path).is_file(), resource_path


def test_player_uses_one_visual_sprite_without_replacing_characterbody_physics():
    assert "extends CharacterBody2D" in PLAYER
    assert "AnimatedSprite2D.new()" in PLAYER
    assert "SpriteFrames.new()" in PLAYER
    assert "move_and_slide()" in PLAYER
    assert "CollisionShape2D.new()" in PLAYER


def test_visual_state_adapter_maps_all_requested_movement_and_mobility_states():
    for state in ["IDLE", "WALK", "RUN", "CROUCH", "JUMP", "FALL", "LAND", "DASH", "GRAPPLE_SHOOT", "GRAPPLE_SWING"]:
        assert f'"{state}"' in PLAYER
    assert "flip_h" in PLAYER
    assert "animation_sprite.play" in PLAYER


def test_wall_climb_slide_and_combat_pack_remain_unintegrated_fallbacks():
    assert '"wall_climb"' not in PLAYER
    assert '"wall_slide"' not in PLAYER
    assert "ATTACK_1" in PLAYER and "BLOCK" in PLAYER and "PARRY" in PLAYER
    assert "attack_active" in PLAYER and "grappling" in PLAYER


def test_visual_animation_does_not_change_gameplay_constants_or_physics_flow():
    for token in ["const SPEED := 300.0", "const JUMP_VELOCITY := -520.0", "const GRAPPLE_REEL_SPEED := 85.0", "const PARRY_WINDOW := 0.18", "_apply_grapple_control(delta, axis, Input.is_action_pressed(\"grapple\"))"]:
        assert token in PLAYER


def test_mobility_pack_source_keeps_wall_animation_frames_without_activating_them():
    mobility = ROOT / "assets/characters/player/mobility"
    assert len(list((mobility / "wall_climb").glob("*.png"))) == 6
    assert len(list((mobility / "wall_slide").glob("*.png"))) == 4
    source = (ROOT / "assets/characters/player/player_mobility_frames.tres").read_text(encoding="utf-8")
    assert '"name": &"wall_climb"' in source
    assert '"name": &"wall_slide"' in source
    player_animation_builder = PLAYER.split("func _create_animation_sprite", 1)[1].split("func _copy_sprite_animations", 1)[0]
    assert '"wall_climb"' not in player_animation_builder
    assert '"wall_slide"' not in player_animation_builder


def test_combat_pack_is_not_imported_into_runtime_project():
    assert not (ROOT / "assets/characters/player/combat").exists()
    assert "player_combat_frames.tres" not in PLAYER


def test_dash_visual_playback_fits_existing_short_dash_window():
    assert "animation_sprite.speed_scale = 2.5 if animation_name == \"dash\" else 1.0" in PLAYER
    assert "const DASH_TIME := 0.20" in PLAYER


def test_each_jump_impulse_restarts_the_one_shot_jump_visual():
    assert PLAYER.count('_last_sprite_animation = ""') >= 3
    assert "const MAX_JUMPS := 2" in PLAYER


def test_all_movement_and_mobility_source_frames_are_present_in_order_and_unique():
    import hashlib
    import struct

    expected = {
        "idle": 8, "walk": 8, "run": 8, "crouch": 4,
        "jump": 6, "fall": 4, "land": 4,
        "dash": 6, "grapple_shoot": 5, "grapple_swing": 8,
        "wall_climb": 6, "wall_slide": 4,
    }
    character_root = ROOT / "assets/characters/player"
    digests = set()
    for animation, count in expected.items():
        folder = character_root / animation if animation in MOVEMENT_ANIMS else character_root / "mobility" / animation
        frames = sorted(folder.glob("*.png"))
        assert len(frames) == count, animation
        for index, frame in enumerate(frames, start=1):
            assert frame.stem.endswith(f"_{index:02d}"), frame.name
            data = frame.read_bytes()
            assert data[:8] == b"\x89PNG\r\n\x1a\n"
            width, height, bit_depth, color_type = struct.unpack(">IIBB", data[16:26])
            assert (width, height) in {(200, 200), (256, 256)}
            assert bit_depth == 8 and color_type == 6
            digest = hashlib.sha256(data).digest()
            assert digest not in digests, f"duplicate image content: {frame}"
            digests.add(digest)
