from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ENEMY = (ROOT / "scripts/enemy.gd").read_text(encoding="utf-8")
AI = (ROOT / "scripts/ai/enemy_ai.gd").read_text(encoding="utf-8")
ALARM = (ROOT / "scripts/mission/alarm_system.gd").read_text(encoding="utf-8")
MAIN = (ROOT / "scripts/main.gd").read_text(encoding="utf-8")


def test_existing_fsm_is_extended_with_patrol_wait_and_look_turns():
    assert "patrol_pause_timer" in ENEMY
    assert "patrol_look_timer" in ENEMY
    assert "func _update_patrol_state(delta: float)" in ENEMY
    assert "patrol_wait_duration" in ENEMY


def test_blocked_enemy_can_recover_without_staying_stuck_forever():
    assert "stuck_timer" in ENEMY
    assert "STUCK_RECOVERY_TIME" in ENEMY
    assert "_recover_from_stuck()" in ENEMY


def test_team_alert_is_bounded_and_does_not_assign_live_player_position():
    assert "signal team_alert" in ALARM
    assert "func receive_team_alert(source_position: Vector2, radius: float, alert_kind: String) -> bool" in ENEMY
    assert "LOCAL_TEAM_RADIUS" in ALARM and "GLOBAL_TEAM_RADIUS" in ALARM
    assert "enemy.receive_team_alert" in MAIN
    receiver = ENEMY.split("func receive_team_alert", 1)[1].split("func _set_ai_state", 1)[0]
    assert "last_known_player_position = target.global_position" not in receiver


def test_ai_controller_remains_single_transition_authority():
    assert "EnemyAIScript.new()" in ENEMY
    assert "_ai_controller.can_transition" in ENEMY
    assert "class_name SilentBladeEnemyAI" in AI
    assert "func can_transition" in AI


def test_lost_sight_uses_last_known_position_and_search_state():
    assert "_begin_search(last_known_player_position)" in ENEMY
    assert '"SEARCH"' in ENEMY and '"RETURN"' in AI


def test_global_alarm_noise_and_team_broadcast_do_not_double_raise_same_suspicion():
    receiver = ENEMY.split("func receive_team_alert", 1)[1].split("func _set_ai_state", 1)[0]
    assert "last_noise_type == \"GLOBAL_ALARM\"" in receiver
    assert "is_equal_approx(investigate_position.distance_to(source_position), 0.0)" in receiver
