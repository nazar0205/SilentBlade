"""Grapple Hook 2.0 contracts; runtime physics still requires Godot validation."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
PLAYER = (ROOT / "scripts/player.gd").read_text(encoding="utf-8")


def block(name: str) -> str:
    match = re.search(rf"func {re.escape(name)}\(.*?(?=\nfunc |\Z)", PLAYER, re.S)
    assert match, f"missing {name}"
    return match.group(0)


def test_grapple_press_attaches_and_release_detaches():
    physics = block("_physics_process")
    assert 'Input.is_action_just_pressed("grapple")' in physics
    assert "_attach_grapple()" in physics
    assert 'Input.is_action_just_released("grapple")' in physics
    assert "_detach_grapple()" in physics


def test_held_grapple_reels_at_a_bounded_rate_without_removing_pendulum_control():
    control = block("_apply_grapple_control")
    assert "GRAPPLE_REEL_SPEED" in PLAYER
    assert "rope_length = maxf(GRAPPLE_MIN_ROPE_LENGTH" in control
    assert "GRAPPLE_PUMP_ACCEL" in control
    assert "reel" in control


def test_grapple_keeps_collision_aware_rope_constraint_and_never_teleports():
    constraint = block("_constrain_rope_after_motion")
    assert "move_and_collide" in constraint
    assert "velocity.dot(radial)" in constraint
    assert "global_position =" not in PLAYER
    assert "not _has_clear_grapple_line(grapple_point)" in PLAYER


def test_grapple_attachment_checks_clear_ray_and_nearest_valid_anchor():
    attach = block("_attach_grapple")
    find = block("_find_grapple_anchor")
    assert "_find_grapple_anchor()" in attach
    assert "_has_clear_grapple_line" in find
    assert "GRAPPLE_RANGE" in find
    assert "get_world_2d().direct_space_state.intersect_ray" in block("_has_clear_grapple_line")


def test_jump_and_focus_loss_detach_without_resetting_velocity():
    jump = block("_try_consume_jump_buffer")
    detach = block("_detach_grapple")
    release = block("release_controls")
    assert "_detach_grapple()" in jump
    assert "_detach_grapple()" in release
    assert "velocity = Vector2.ZERO" not in detach
    assert "velocity.x = 0.0" not in detach


def test_anchor_feedback_and_rope_visual_are_present():
    draw = block("_draw")
    assert "grapple_target" in PLAYER
    assert "draw_line(Vector2(0, -48), anchor_local" in draw
    assert "draw_arc" in draw or "draw_circle" in draw


def test_roof_tutorial_explains_hold_to_reel_and_release_to_swing():
    import json
    mission = json.loads((ROOT / "data/missions/mission_01.json").read_text(encoding="utf-8"))
    roofs = next(item for item in mission["tutorial"] if item["id"] == "roofs")
    assert "удерживай для подтягивания" in roofs["text"].lower()
    assert "отпусти" in roofs["text"].lower()
