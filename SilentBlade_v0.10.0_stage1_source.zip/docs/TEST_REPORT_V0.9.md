# SILENT BLADE v0.9.0 — Test Report

## Environment

- Target engine: Godot 4.3.
- Script language: GDScript.
- Target platform: Android, landscape, arm64-v8a debug APK.
- Local engine availability: no `godot` / `godot4` executable.
- Local Android availability: no ADB/Android SDK/Gradle.
- Git remote: not configured; GitHub Actions could not be dispatched from this environment.

## Executed checks

| Check | Result |
|---|---|
| Full Python test suite | **164 passed** |
| Combat phase/buffer static contracts | Passed |
| Enemy FSM/patrol/team-alert static contracts | Passed |
| Noise profile/deduplication static contracts | Passed |
| Checkpoint/statistics/ranking static contracts | Passed |
| Android version metadata (name 0.9.0/code 10) | Passed statically |

The 164 Python tests inspect source contracts and project structure. They do not compile GDScript or run the game.

## Added but not executed here

`tests/godot/v09_gameplay_systems_test.gd` exercises real Godot nodes for:
- wind-up/active/recovery and hitbox enable/disable;
- per-swing hit deduplication and enemy stagger/knockback;
- buffered combo links, including a tap after the prior attack ended;
- successful parry interruption and counter window;
- enemy FSM transitions;
- noise event reception, location memory and event-ID deduplication;
- global siren noise plus team broadcast deduplication;
- mission counters and checkpoint restoration;
- ranking explanation and persistent best-score non-downgrade.

The Godot script is wired into `.github/workflows/godot-validation.yml`, but was **not run locally**.

## Not verified

- Godot 4.3 GDScript parser/import.
- Main scene headless launch.
- Actual gameplay combat timings and visual animation sync.
- AI behavior under multiple active enemies in a running scene.
- Physical Android multitouch and pause/resume.
- Android APK export/signature/install/runtime.
- GitHub Actions results.

No Android APK is included. Do not treat Python static contracts as evidence of runtime or device compatibility.

## Additional static checks

- Both GitHub Actions workflow YAML files parsed successfully.
- Every `run:` shell script extracted from YAML passed `bash -n` (including nested heredoc in Android build workflow).
- 66 `res://` references in GDScript/scenes/project configuration resolve to existing files.
- No duplicate GDScript function names were found.
- All WAV assets passed RIFF metadata/readability checks.
- Android export preset was verified as version `0.9.0`, code `10`, APK path `build/SilentBlade-v0.9.0-debug.apk`.

## Source preservation

Compared with the uploaded v0.8.1 archive: 75 original files were present; zero were deleted, 17 were modified and 14 were added for v0.9 combat effects, Godot runtime tests, Python contracts and documentation.
