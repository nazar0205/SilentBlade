# SILENT BLADE v0.10.0 — Stage 1 Test Report

## Executed locally

- ZIP integrity checks for all four supplied source archives: passed during intake.
- Imported PNG decode check with Pillow: **76/76 PNGs decoded**; 75 RGBA and 1 RGB (opaque Sky layer). Frame dimensions and SpriteFrames references are also covered by Python tests.
- SpriteFrames references: Python tests confirm every referenced PNG path exists.
- Focused graphics tests: `pytest -q tests/test_v10_player_animation_integration.py tests/test_v10_parallax_layers.py` — **18 passed**.
- Full regression suite after final source edits: `pytest -q` — **182 passed**.

The Python suite checks asset contracts, frame definitions, paths, the player visual adapter's source wiring, selected/fallback animation boundaries, parallax factors/coverage, and existing project regression contracts. It is not a substitute for loading the project in Godot.

## Added but not locally executed

- `tests/godot/v10_player_animation_test.gd`: loads the real player, inspects all 10 integrated animations and frame counts, checks facing, fallback selection, grapple shoot-to-swing transition and preservation of collision/hitbox nodes.
- `tests/godot/v10_background_parallax_test.gd`: loads the actual mission level and inspects all five Parallax2D nodes, texture dimensions, order, scroll factors and absence of collision geometry.
- Both tests are wired into `.github/workflows/godot-validation.yml`.

## Not verified in this environment

- Godot 4.3 project import and GDScript parser.
- Main scene runtime and actual rendered animation appearance.
- Camera/parallax visual continuity during gameplay.
- Android device rendering, memory and frame rate.
- Android APK export.

No runtime or APK success is claimed.
