# SILENT BLADE v0.8.1 — Test Report

## Environment

- Target: Godot 4.3, GDScript, Android landscape.
- Python 3.13 and pytest 9.0.2 available.
- Godot/Godot 4, ADB, Android SDK `sdkmanager`, Gradle, Docker and Podman unavailable.
- No configured Git remote exists in this extracted project, so GitHub Actions could not be dispatched from this environment.
- An attempt to reach the official Godot release host failed at DNS resolution (`Could not resolve host: github.com`). No binary was downloaded.

## Python test suite

Command:

```bash
python -m pytest -q
```

Final fresh run in the project directory: **133 passed**.

The full suite includes the original v0.4.1–v0.8 static contracts plus new v0.8.1 tests. The new tests check:

- Data-driven physical platform descriptors and a connected roof route across all five zones.
- Zone A starter steps, jump/double-jump reachability bounds and the platform jump envelope.
- Opaque house wall collision and the archive doorway/door alignment.
- Grapple press-to-attach, hold-to-reel, release/jump detach, minimum rope length, line-of-sight query, collision-aware rope correction and velocity retention contracts.
- Eight independent Android touch actions and non-overlapping padded hit regions at four landscape resolutions and three settings values (12 resolution/scale combinations), with controls kept outside the joystick touch zone and within viewport bounds.
- Pause-menu settings, ConfigFile persistence, viewport relayout, debug overlay default, and registered touch-control type.
- Android export metadata and workflow wiring for v0.8.1.

The Python suite reads source/configuration and runs a mathematical reachability model. It is not a substitute for importing the scripts or simulating a real level in Godot.

## Additional static validation

- `data/missions/mission_01.json` parsed successfully: 28 platforms and 13 grapple anchors.
- Both GitHub Actions workflow YAML files parsed successfully.
- Every embedded shell `run: |` block passed `bash -n`.
- All `res://` resource references found in GDScript, scenes and configuration point to files that exist.
- No duplicate GDScript function names were found in individual scripts.
- Android preset metadata reads version code 9 / version name 0.8.1, and preset/workflow APK paths match.

## Godot headless test added, not run locally

`tests/godot/v081_grapple_touch_test.gd` is added and invoked by `.github/workflows/godot-validation.yml`. It instantiates the real touch-controls node and player node, then checks:

- Simultaneous jump/grapple finger ownership and independent release.
- Grapple attaches without snapping position.
- Holding calls the bounded rope-reel path.
- Detaching preserves velocity and position.
- A real `StaticBody2D` wall blocks the grapple ray.

The test has not been executed because Godot 4.3 is unavailable here. Runtime success must be established from its CI log after the workflow is run.

## Android APK

- `export_presets.cfg` now exports version 0.8.1, version code 9, to `build/SilentBlade-v0.8.1-debug.apk`.
- `.github/workflows/android-build.yml` is updated to upload the matching v0.8.1 arm64-v8a artifact.
- No APK was produced in this environment. The Android workflow was not run because there is no configured Git remote/CI dispatch and Android build tools are absent.
- No on-device installation or performance test is claimed.

## Known unverified behavior / risks

1. The mathematical platform graph cannot validate all collision corner cases, capsule edge contacts, moving transitions or real controller timing. A full five-zone playthrough is still required in Godot 4.3.
2. Reel correction uses `move_and_collide()` after `move_and_slide()` on the same physics tick. This needs runtime profiling and collision verification inside Godot, especially when the rope points diagonally through crowded geometry.
3. If a wall blocks the rope line after movement, the hook detaches. This deliberately prevents rope-through-wall behavior, but corner wrapping is not supported.
4. Touch hit zones are statically checked; finger ergonomics, safe areas and visibility must still be evaluated on actual Android devices at 16:9 and 19.5:9.
5. The pause panel layout and persisted ConfigFile settings have not been observed in a running Godot UI.
6. Android APK signature, architecture, package metadata and installation remain unverified until the CI artifact exists.
