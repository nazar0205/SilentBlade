# SILENT BLADE v0.9.0 Gameplay Systems Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Upgrade existing combat, AI, noise, checkpoint and mission-results systems without replacing the v0.8.1 project.

**Architecture:** Extend `player.gd`, `enemy.gd`, the current FSM and mission managers. Add small animation-state and combat-effect helpers; use signals to centralize mission counters and bounded team-alert messages.

**Tech Stack:** Godot 4.3, GDScript, Python/pytest static contracts, Godot headless smoke scripts.

**Spec:** `docs/superpowers/specs/2026-11-28-v09-gameplay-systems-design.md`

## Global Constraints
- Godot 4.3; GDScript; Android landscape.
- Do not replace the existing project, Mission 01, CharacterBody2D, current touch input, existing FSM, or the existing NoiseSystem.
- Retain one-hit-per-target-per-swing and hold-to-block/parry.
- Keep perception interval-based and transient effects bounded.

## Review Focus
- Attack starts/ends during physics frame boundaries; the hitbox must only be active during the authored active phase.
- A held/buffered combo input must not produce duplicate attacks or skip combo steps.
- A parry during TELEGRAPH/EXECUTE must interrupt once; a non-parried attack must still resolve at most once.
- Multiple nearby enemies receiving one team alert must investigate the signal point, not obtain the player's live position.
- Checkpoint death/respawn must preserve unique IDs and monotonically increasing statistics while resetting enemy runtime state.

---

### Task 1: Combat phase and combo buffer
**Files:** Modify `scripts/player.gd`; test `tests/test_v09_combat_contract.py`.
**Interfaces:** Player owns `attack_phase`, `attack_phase_timer`, `attack_buffer_timer`; signals `attack_started(index)`, `attack_hit(target_id, damage)`, `damage_received(amount)`, `grapple_used`, `distraction_used`.
- [x] Add tests for 3-step profile order, wind-up/active/recovery, active-only hitbox, combo buffer, one target per swing.
- [x] Run RED.
- [x] Implement phase transitions and buffered continuation.
- [x] Run focused and full tests.

### Task 2: Animation state and combat feedback
**Files:** Modify `scripts/player.gd`, `scripts/enemy.gd`, `scripts/main.gd`; create `scripts/combat/impact_effect.gd`; add small WAV effects.
**Interfaces:** Player/Enemy expose `animation_state`; main spawns capped effect nodes and applies subtle camera feedback.
- [x] Add tests for state priority and attack-active synchronization.
- [x] Run RED.
- [x] Implement state-driven procedural poses and light impact VFX/audio.
- [x] Run focused and full tests.

### Task 3: Enemy AI 2.0 and team alert
**Files:** Modify `scripts/enemy.gd`, `scripts/ai/enemy_ai.gd`, `scripts/mission/alarm_system.gd`, `scripts/main.gd`; test `tests/test_v09_ai_contract.py`.
**Interfaces:** `receive_team_alert(source_position: Vector2, radius: float, alert_kind: String) -> bool`; alarm emits `team_alert(source_position, radius, mode)`.
- [x] Add tests for patrol wait/turn, stuck escape, bounded local/global team alert, no current-position leak, search and recovery.
- [x] Run RED.
- [x] Implement behaviors inside existing FSM.
- [x] Run focused and full tests.

### Task 4: Noise 2.0 and distraction response
**Files:** Modify `scripts/stealth/noise_system.gd`, `scripts/stealth/noise_decoy.gd`, `scripts/enemy.gd`; test `tests/test_v09_noise_contract.py`.
**Interfaces:** Noise events retain `id`, `position`, `radius`, `intensity`, `event_type`, `source_id`; add event weight/priority and listener dedupe.
- [x] Add tests for noise profile differences, dedupe, physical decoy collision and investigation location.
- [x] Run RED.
- [x] Implement normalized event weights and bounded response.
- [x] Run focused and full tests.

### Task 5: Checkpoint snapshots and mission event statistics
**Files:** Modify `scripts/mission/checkpoint_system.gd`, `scripts/mission/mission_manager.gd`, `scripts/main.gd`; test `tests/test_v09_progress_contract.py`.
**Interfaces:** `MissionManager.record_event(event_name: String, amount: float = 1.0)`; `CheckpointSystem` stores a versioned `mission_state` payload.
- [x] Add tests for all counters, snapshot completeness, unique item dedupe and no counter rewind.
- [x] Run RED.
- [x] Implement event counters and versioned snapshots.
- [x] Run focused and full tests.

### Task 6: Ranking 2.0 and persistent best result
**Files:** Modify `scripts/mission/mission_results.gd`, `scripts/mission/mission_manager.gd`, `scripts/main.gd`; test `tests/test_v09_ranking_contract.py`.
**Interfaces:** `score(stats) -> int`, `evaluate(stats) -> String`, `explain(stats) -> Array[String]`, `load_best(mission_id) -> Dictionary`, `save_best(mission_id, result) -> bool`.
- [x] Add boundary tests for S/A/B/C/D and best-result update/no-downgrade.
- [x] Run RED.
- [x] Implement fixed score rubric, reasons and ConfigFile persistence.
- [x] Run focused and full tests.

### Task 7: Android UX, release metadata, docs and final validation
**Files:** Update README, docs, workflows, export preset; add Godot runtime tests.
- [x] Test that existing touch actions map to new stats/events without new buttons.
- [x] Run the complete Python suite, YAML/shell validation, resource-reference and JSON checks.
- [x] Run Godot import/headless tests and Android export only if the engine/SDK/remote are available.
- [x] Package ZIP and independently test the extracted archive.
