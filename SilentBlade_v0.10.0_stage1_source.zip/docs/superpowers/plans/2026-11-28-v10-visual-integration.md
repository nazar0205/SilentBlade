# SILENT BLADE v0.10.0 Visual Integration — Implementation Plan

> **For agentic workers:** execute task-by-task with tests before implementation.

**Goal:** Integrate seven movement animations, three safe mobility animations, and five Bamboo Forest Parallax2D layers into the existing Godot 4.3 project.

**Architecture:** Preserve CharacterBody2D physics and gameplay state ownership in player.gd. Add one child AnimatedSprite2D as a visual-only renderer driven by existing player states; retain procedural drawing for feedback overlays and unsupported states. Keep background artwork in five decorative Parallax2D nodes without collision geometry.

**Tech Stack:** Godot 4.3, GDScript, SpriteFrames, AnimatedSprite2D, Parallax2D, Python/pytest.

**Spec:** User's v0.10.0 graphics integration request and confirmed first-stage scope.

## Global Constraints
- Godot 4.3, GDScript, Android landscape.
- Integrate all seven Movement animations.
- Integrate Dash, Grapple Shoot, Grapple Swing; preserve Wall Climb/Wall Slide source files but use fallback.
- Integrate all five Bamboo Forest layers with Parallax2D.
- Do not integrate Combat Pack.
- Preserve physics, collision, combat, grapple, AI, stealth, checkpoints, ranking and Android controls.

## Review Focus
- Sprite pivot/size consistency: verify source image dimensions and alpha bounds; use uniform scale and fixed feet pivot.
- Visual state priority: combat/hit/block must not be overridden by locomotion; test priority mapping.
- Grapple shoot-to-swing transition: test one-shot shoot and looped swing without affecting grapple physics.
- Land/jump one-shots: ensure they do not restart every frame or persist after their visual timer.
- Parallax coverage: verify all 5 source textures cover camera travel and no collision nodes are generated.

### Task 1: Import movement and safe mobility assets
- [x] Extract source PNGs and SpriteFrames resources into assets/characters/player while preserving source assets.
- [x] Verify every SpriteFrames texture path resolves and count the seven movement and three safe mobility animations.

### Task 2: Animated player visual adapter
- [x] Add tests for required resource paths, animation state mapping and preservation of gameplay scripts.
- [x] Add AnimatedSprite2D as a child of the existing player; merge only the selected SpriteFrames animations.
- [x] Drive animation playback from existing state, facing, dash and grapple timers.
- [x] Keep wall climb/slide and unsupported combat/death states on procedural fallback.
- [x] Keep procedural feedback overlays (rope, hit/parry/block flash, attack trails) separate from the sprite.

### Task 3: Bamboo Forest Parallax2D
- [x] Keep five Parallax2D layers and tune scroll scales for 6200 px mission width and 19.5:9 viewport.
- [x] Confirm decorative-only sprites and no physics geometry.

### Task 4: CI, docs and release package
- [x] Add Godot headless tests for SpriteFrames, player visual child and five Parallax2D nodes.
- [x] Update README, asset register and validation report.
- [x] Run full pytest suite; run Godot 4.3 import/headless test if executable exists.
- [x] Package full ZIP and verify it by extracting and rerunning tests.
