# SILENT BLADE v0.8.1 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Make Mission 01 traversable, add controlled hold-to-reel grappling, and improve configurable Android touch controls without replacing v0.8 systems.

**Architecture:** Keep the dynamic `MissionLevel` builder and make its platform geometry data-driven from `mission_01.json`. Extend the existing player rope constraint with bounded rope retraction while `grapple` is held. Keep the single raw-touch layer and expose its existing scale/opacity values through pause-menu settings.

**Tech Stack:** Godot 4.3, GDScript, Python/pytest static and geometry tests, existing GitHub Actions workflows.

**Spec:** `docs/superpowers/specs/2026-11-28-v081-core-gameplay-design.md`

## Global Constraints
- Godot 4.3, GDScript, Android landscape.
- Preserve v0.8 mission, combat, stealth, AI, objectives, alarm, checkpoint and results behavior.
- No direct player position teleportation for grappling.
- Keep per-finger touch ownership and focus-loss release behavior.

## Review Focus
- Releasing the grapple finger must detach even when a short touch was deferred across one physics tick.
- Holding jump while hooked must detach only once and not reattach until the grapple button is pressed again.
- Reeling near a wall must stop/detach instead of pulling through the wall.
- Platform geometry must leave the doorways, archive item, alarm panel, and evacuation interactables reachable.
- Ultrawide touch controls must remain within the viewport and have non-overlapping hit regions.

---

### Task 1: Level geometry contract

**Files:**
- Modify: `data/missions/mission_01.json`
- Create: `tests/test_v081_level_reachability.py`
- Test existing: `scripts/mission/mission_level.gd`

**Interfaces:**
- Data schema: `platforms[]` entries contain `id`, `x`, `y`, `width`, `height`, `color`.
- `MissionLevel` consumes `config.platforms` and creates physical `StaticBody2D` platforms.

- [ ] Write tests for the platform list and graph reachability using player jump constants.
- [ ] Run tests and observe expected failure before production edits.
- [ ] Add the canonical platform descriptors to the mission JSON, including safer Zone A steps, lower Zone B2/E2 roof surfaces, and preserve all five areas.
- [ ] Run the geometry tests and full Python suite.

### Task 2: Physical house/archive collision integration

**Files:**
- Modify: `scripts/mission/mission_level.gd`
- Modify: `scripts/mission/mission_interactable.gd` only if doorway interaction requires a small interface adjustment.
- Test: `tests/test_v081_level_reachability.py`

**Interfaces:**
- `_add_house(pos)` creates lower-wall `StaticBody2D` collision behind its art.
- `_add_archive_facade(pos)` creates two wall sections with a doorway gap.
- Archive door interactable aligns with archive facade at x=4210.

- [ ] Add failing checks for opaque wall collision and archive door alignment.
- [ ] Add lower wall collision without intersecting roof surfaces.
- [ ] Add two archive wall sections and align the door with the opening.
- [ ] Verify ground bypass and rooftop surfaces remain present.
- [ ] Run geometry tests and full Python suite.

### Task 3: Grappling Hook 2.0

**Files:**
- Modify: `scripts/player.gd`
- Test: `tests/test_v081_grapple_contract.py`
- Modify: `tests/godot/gameplay_smoke_test.gd` if the existing runtime test can assert behavior.

**Interfaces:**
- `func _attach_grapple() -> void`
- `func _find_grapple_anchor() -> Vector2`
- `func _apply_grapple_control(delta: float, axis: float, reel: bool) -> void`
- `func _detach_grapple() -> void` retains current velocity.
- `grapple` pressed attaches; `grapple` released detaches; `jump` while hooked detaches via jump-buffer consumption.

- [ ] Write failing tests for press/hold/release semantics, bounded reel speed, line-of-sight, collision-aware constraint, and velocity preservation.
- [ ] Run those tests to observe failure.
- [ ] Implement bounded rope shortening (85 px/s) only while held; retain min rope length.
- [ ] Keep tangential acceleration and outward radial velocity projection.
- [ ] Add cached valid-anchor feedback and visible anchor/rope rendering.
- [ ] Run grapple tests and full Python suite.

### Task 4: Android touch layout and settings

**Files:**
- Modify: `scripts/input/touch_controls.gd`
- Modify: `scripts/main.gd`
- Test: `tests/test_v081_touch_controls.py`

**Interfaces:**
- Keep `get_button_center`, `get_button_radius`, `get_button_actions`, `release_all`.
- Keep all actions in `BUTTON_DEFS`.
- `button_scale` and `button_opacity` remain exported properties.
- Settings persist in `user://silent_blade_controls.cfg`.

- [ ] Write failing tests that parse button layout and assert padded hit regions do not overlap at 1280x720 and 19.5:9.
- [ ] Write failing checks for visible settings controls and config persistence.
- [ ] Reduce stick/button visual sizes and arrange buttons in four columns/two rows.
- [ ] Add pause menu sliders and immediate persistence.
- [ ] Keep debug overlay disabled in normal UI.
- [ ] Run touch tests and full Python suite.

### Task 5: Integration, documentation and packaging

**Files:**
- Modify: `README.md`
- Create: `docs/V0.8.1_CORE_GAMEPLAY.md`
- Create: `docs/TEST_REPORT_V0.8.1.md`
- Update: `.github/workflows/godot-validation.yml` only if the existing validation workflow needs test discovery changes.

- [ ] Run `python -m pytest -q` from the project root.
- [ ] Run source path, JSON, YAML and GDScript delimiter sanity checks.
- [ ] Check for Godot 4.3 and Android build tools; run import/headless/export only if present.
- [ ] Package full source ZIP; run `unzip -t`.
- [ ] Extract the ZIP to a clean folder and repeat the full Python suite.
- [ ] Report statically verified behavior separately from Godot runtime and Android build/device behavior.

