# SILENT BLADE v0.8.1 — Core Gameplay Design

## Intent
Repair Mission 01 traversal and mobile controls while preserving the v0.8 mission, combat, stealth, AI, objectives, alarm, checkpoints, and results.

## Goals
- Make the roof route physically reachable with the existing two-jump movement model and keep the ground route available.
- Make the grapple a hold-to-reel system: press to attach, hold to gradually shorten the rope, release or jump to detach while preserving velocity.
- Keep rope collision/line-of-sight constraints; never set the player position directly.
- Make Android action hit regions non-overlapping at 16:9 and ultrawide landscape sizes.
- Expose button size and opacity settings and persist them locally.
- Add solid collision to prominent house/archive walls without sealing intended routes.

## Non-goals
- Do not redesign the five-zone mission or replace its systems.
- Do not add a spring/elastic launch mechanic, teleport movement, new inventory, or a second input stack.
- Do not claim Godot runtime or APK verification without running the relevant toolchain.

## Constraints
- Godot 4.3, GDScript, Android landscape, existing GL Compatibility renderer.
- Preserve `Main.tscn`, `project.godot`, v0.8 managers, combat, stealth, enemy AI, mission goals and checkpoint semantics.
- Use the current `CharacterBody2D`, `move_and_slide`, collision-aware rope constraint and `PhysicsRayQueryParameters2D`.
- Keep raw multitouch ownership per finger.

## Approaches
1. **Reel rope length while held (selected).** Reduce the target rope length at a bounded px/s rate; existing post-motion constraint resolves only the small excess via collision. Release leaves velocity untouched. This preserves the pendulum and avoids introducing a second movement force that competes with collision resolution.
2. Add a spring force toward the anchor. Rejected: it can introduce oscillatory speed spikes and does not naturally enforce a strict rope length.
3. Move the character toward the anchor with `move_toward` or direct transform changes. Rejected: it weakens pendulum motion and risks clipping through geometry.

For level geometry, use a data-driven `platforms` list in `mission_01.json` so the same layout is used by the builder and reachability tests. Add small steps and lower only the two borderline roof surfaces; preserve the elevated route.

For touch controls, use a four-column/two-row button layout with separate visual radius and touch padding. Add pause-menu sliders backed by `user://silent_blade_controls.cfg`.

## Acceptance criteria
- The roof-route platform graph connects from the spawn approach to every required zone with at most two jumps per transition; maximum platform rise remains within measured double-jump capability.
- The roof route has no single-jump borderline rise above the calculated single-jump apex.
- House and archive wall geometry blocks player movement and the grapple/vision ray, while doors provide the intended passage.
- Grapple attaches only to reachable, unobstructed anchors; while held, rope length decreases at a bounded rate; releasing or jumping detaches without resetting velocity.
- No direct `global_position` correction is introduced for grappling.
- Grapple line and valid-target feedback are visible.
- Touch hit regions do not overlap at 1280x720 and 19.5:9 landscape; all eight controls retain independent finger ownership.
- Size and opacity settings apply immediately and persist between launches.
- Existing 113 v0.8 tests remain passing.
- Godot runtime, Android build and device tests are reported separately as verified or not verified.

## Builder decisions
- Reel speed default: 85 px/s; min rope length remains 90 px.
- The grapple button is held to reel and releases to detach; keyboard E follows the same behavior.
- House wall colliders cover the lower wall only, leaving roof platforms unobstructed.
- Archive side door is aligned with the facade at x=4210; archive wall sections leave a doorway gap.
- Default touch button scale: 0.92; opacity: 0.78. Pause sliders allow size 0.78–1.12 and opacity 0.42–0.92.
