# SILENT BLADE v0.9.0 — Gameplay Systems Design

## Intent
Extend the current v0.8.1 vertical slice with a deeper combat loop, visible combat/AI states, more deliberate enemy patrol/search/team alert behavior, richer noise reactions, reliable run-session checkpoint snapshots, and centrally recorded mission statistics with explainable ranking and a saved best result.

## Goals
- Keep the three katana stages and make their wind-up, active hitbox, recovery, and input buffer explicit.
- Preserve one-hit-per-target-per-swing, hold-to-block, parry interruption, stagger, knockback, and Android multitouch.
- Use an animation-state layer that drives the current procedural character drawings; do not fake animation with random scale changes or require unavailable sprite sheets.
- Improve the existing enemy FSM in `enemy.gd` and transition controller in `ai/enemy_ai.gd`; do not introduce a parallel FSM.
- Add local/team alarm propagation with bounded radius and no live player-position leakage after LOS is lost.
- Centralize mission statistics through one event API and add persistent best-rank/result data distinct from run-session checkpoint state.

## Non-goals
- No new mission or campaign chapter.
- No replacement of current combat, AI, stealth, movement, level or touch-control systems.
- No new combat button; existing controls are retained.
- No sprite-sheet art dependency or heavyweight particle/lighting system.
- No claim of Android/device readiness without real export and device verification.

## Constraints
- Godot 4.3, GDScript, Android landscape, GL Compatibility.
- Preserve project paths, current Main.tscn, Mission 01, current input actions and the v0.8.1 project contents.
- Keep vision checks interval-based and cap transient VFX/audio instances.

## Approaches
1. Replace combat and AI with new components — rejected because it duplicates working v0.8.1 systems and risks regression.
2. Extend current player/enemy state and add small event/animation/VFX helpers — selected because existing CharacterBody2D combat hitboxes, FSM transition whitelist, NoiseSystem and MissionManager provide usable integration points.
3. Depend on new sprite sheets and AnimationTree — rejected because no sprite sheets exist in the uploaded project and this would introduce an asset dependency not required by the request.

## Architecture decisions
- `player.gd` owns attack phases and the single active hitbox. Attack profile timings drive the visual state and hitbox activation.
- `enemy.gd` keeps its existing FSM and profile data; `enemy_ai.gd` remains the transition authority. `AlarmSystem` emits bounded team-alert events; nearby enemies react through a dedicated receiver method.
- Procedural animations are state-driven poses and timed weapon/limb strokes over the existing hand-drawn characters. They are not random transforms.
- `MissionManager.record_event(event_name, amount)` is the only counter mutation API for new combat telemetry. Player/enemy signals are connected in `main.gd`.
- Checkpoints preserve active-run progress and statistics; persistent best-result records are stored separately with ConfigFile under `user://`.
- Mission ranking is deterministic and transparent: success required; score from time, detections, alarms, damage, neutralizations, secrets, documents and optional objectives; thresholds are fixed and documented.

## Acceptance criteria
- Each attack has wind-up/active/recovery; hitbox active only during the active phase; input buffered during the combo link; each target hit once per swing.
- Block and parry semantics remain intact; parry interrupts to STAGGER and emits visual/audio feedback.
- Player and enemy expose the requested animation state names and draw matching procedural poses without changing collision sizes.
- Enemy patrol includes stops/look turns, blocked-motion recovery and bounded team alert. Lost sight searches the last known position, not current player coordinates.
- Noise types have differentiated weights; decoy remains physical and emits one event at its collision location.
- Checkpoint snapshots include a versioned mission progress snapshot; death does not duplicate collected IDs or reset elapsed time/counters.
- Mission stats include attacks, hits landed, parries, damage taken, grapple uses and distractions, in addition to existing stats.
- Mission result includes score/reasons and previous best when available; S/A/B/C/D rules have automated boundary tests.
- Existing Android touch actions and all v0.8.1 systems remain covered by regression tests.
